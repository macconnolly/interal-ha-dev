#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
PRIMARY_ROOT="/home/mac/HA/implementation_10"
LOCAL_INTEGRATION_DIR="$REPO_ROOT/custom_components/tunet_inbox"
BACKUP_ROOT="$REPO_ROOT/Backups/tunet_inbox"
REMOTE_PARENT="/config/custom_components"
REMOTE_DIR="$REMOTE_PARENT/tunet_inbox"
REMOTE_CONFIG="/config/configuration.yaml"

log() {
  printf '[tinbox:deploy] %s\n' "$*"
}

fail() {
  printf '[tinbox:deploy] ERROR: %s\n' "$*" >&2
  exit 1
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || fail "missing command: $1"
}

resolve_env_file() {
  if [[ -f "$REPO_ROOT/.env" ]]; then
    printf '%s' "$REPO_ROOT/.env"
    return
  fi
  if [[ -f "$PRIMARY_ROOT/.env" ]]; then
    printf '%s' "$PRIMARY_ROOT/.env"
    return
  fi
  fail ".env not found in worktree or primary root"
}

require_cmd sshpass
require_cmd ssh
require_cmd scp
require_cmd tar

ENV_FILE="$(resolve_env_file)"
# shellcheck disable=SC1090
source "$ENV_FILE"

HA_SSH_HOST="${HA_SSH_HOST:-10.0.0.21}"
HA_SSH_USER="${HA_SSH_USER:-root}"
HA_SSH_PASSWORD="${HA_SSH_PASSWORD:-password}"

mkdir -p "$BACKUP_ROOT"
TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"
BACKUP_FILE="$BACKUP_ROOT/tunet_inbox_remote_${TIMESTAMP}.tar.gz"
CONFIG_BACKUP_FILE="$BACKUP_ROOT/configuration_remote_${TIMESTAMP}.yaml"

SSH_OPTS=(-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null)

log "backing up remote integration if present"
if sshpass -p "$HA_SSH_PASSWORD" ssh "${SSH_OPTS[@]}" "$HA_SSH_USER@$HA_SSH_HOST" "test -d '$REMOTE_DIR'"; then
  sshpass -p "$HA_SSH_PASSWORD" ssh "${SSH_OPTS[@]}" "$HA_SSH_USER@$HA_SSH_HOST" \
    "tar -czf - -C '$REMOTE_PARENT' tunet_inbox" > "$BACKUP_FILE"
  log "backup created: $BACKUP_FILE"
else
  log "no remote tunet_inbox directory found; skipping remote backup"
fi

log "backing up remote configuration.yaml"
if sshpass -p "$HA_SSH_PASSWORD" ssh "${SSH_OPTS[@]}" "$HA_SSH_USER@$HA_SSH_HOST" "test -f '$REMOTE_CONFIG'"; then
  sshpass -p "$HA_SSH_PASSWORD" scp "${SSH_OPTS[@]}" \
    "$HA_SSH_USER@$HA_SSH_HOST:$REMOTE_CONFIG" "$CONFIG_BACKUP_FILE"
  log "configuration backup created: $CONFIG_BACKUP_FILE"
else
  fail "remote configuration file not found at $REMOTE_CONFIG"
fi

log "ensuring remote configuration.yaml contains tunet_inbox bootstrap"
sshpass -p "$HA_SSH_PASSWORD" ssh "${SSH_OPTS[@]}" "$HA_SSH_USER@$HA_SSH_HOST" "python3 - '$REMOTE_CONFIG'" <<'PY'
import pathlib
import sys

TINBOX_BLOCK = """tunet_inbox:
  notify_device_helper: input_text.notify_target_device_id
  max_pending_items: 64
  response_timeout_seconds: 30
  archive_retention_days: 3
  privacy_mode_default: false
  debug_events: false
"""

LOGGER_ENTRIES = [
    "    custom_components.tunet_inbox: debug",
    "    custom_components.tunet_inbox.mobile: info",
]

path = pathlib.Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
changed = False

if "\ntunet_inbox:\n" not in text and not text.startswith("tunet_inbox:\n"):
    anchor = "\n# Setup the custom dashboard"
    idx = text.find(anchor)
    if idx == -1:
        raise SystemExit("Could not find dashboard anchor for tunet_inbox bootstrap block")
    insertion = "\n" if not text.endswith("\n") else ""
    text = text[:idx] + insertion + TINBOX_BLOCK + "\n" + text[idx:]
    changed = True

lines = text.splitlines()
missing_logger_entries = [entry for entry in LOGGER_ENTRIES if entry not in lines]
if missing_logger_entries:
    insert_after = None
    for index, line in enumerate(lines):
        if line.strip().startswith("custom_components.tunet_inbox"):
            insert_after = index
    if insert_after is None:
        for index, line in enumerate(lines):
            if line.strip().startswith("custom_components.lighting_manager:"):
                insert_after = index
    if insert_after is None:
        for index, line in enumerate(lines):
            if line.strip() == "logs:":
                insert_after = index
    if insert_after is None:
        raise SystemExit("Could not find logger.logs anchor for tunet_inbox logger entries")
    lines[insert_after + 1:insert_after + 1] = missing_logger_entries
    changed = True

if changed:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

print("updated" if changed else "unchanged")
PY

log "creating remote parent path"
sshpass -p "$HA_SSH_PASSWORD" ssh "${SSH_OPTS[@]}" "$HA_SSH_USER@$HA_SSH_HOST" \
  "mkdir -p '$REMOTE_PARENT'"

log "deploying integration directory"
sshpass -p "$HA_SSH_PASSWORD" scp -r "${SSH_OPTS[@]}" "$LOCAL_INTEGRATION_DIR" \
  "$HA_SSH_USER@$HA_SSH_HOST:$REMOTE_PARENT/"

log "deploy complete"
log "restart Home Assistant before running tinbox:smoke"
