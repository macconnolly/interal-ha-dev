# Tunet Inbox Handoff

Last updated: 2026-04-06 (America/Denver)  
Working branch: `tunet/inbox-integration`

## Current State

- `tunet_inbox` is being introduced as a new governed custom integration.
- The workstream now has its own scoped execution contract under `custom_components/tunet_inbox/`.
- The program-level status ledger for the project is now:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- `TI0` is closed.
- `TI1` is closed.
- `TI1A` is closed.
- `TI1B` is closed.
- `TI1C` is active.
- Active execution authority:
  - `custom_components/tunet_inbox/Docs/tranches/TI1C_corruption_quarantine_repairs_and_release_verification.md`
- No `Dashboard/Tunet/**` work is active in this branch right now.
- No package migrations should be treated as active.

## What Changed This Session

- created the local governance workstream
- fixed the contract source-of-truth location under `custom_components/tunet_inbox/`
- added an explicit planning-control rule:
  - use default execution inside an approved tranche
  - re-enter planning only at tranche or contract control points
- added the normalized program ledger:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- authored tranche specs for:
  - `TI1`
  - `TI2`
  - `TI3`
- replaced the stale dashboard-centric enhancement tracker with:
  - `HA-References/tunet_inbox_enhancement_matrix.md`
- closed the TI0 repo blockers by:
  - wiring `tinbox:*` commands into `package.json`
  - adding the local `tunet_inbox:` bootstrap block and logger wiring to `Configuration/configuration.yaml`
  - passing `py_compile`, `node --check`, and `npm run tinbox:check`
- patched the backend contract/runtime by:
  - allowing free-text titles and action titles
  - validating dashboard response sources explicitly
  - resolving helper-driven mobile targets to `notify.mobile_app_<device_id>`
  - clearing matching mobile notifications on `dismiss`
  - emitting queue refresh events when timeout recovery returns items to `pending`
  - logging malformed restore payload skips instead of silently dropping them
- hardened the deploy path by:
  - backing up remote `configuration.yaml`
  - patching only the governed `tunet_inbox` bootstrap/logger fragments on the live HA host
  - avoiding full-file overwrite of a diverged remote config
- recorded HA/live proof:
  - deploy completed
  - config check returned valid
  - HA restart succeeded
  - smoke passed
  - live service probes covered `post`, `list_items`, `respond`, `fail`, `resolve`, and `dismiss`
  - timeout recovery returned a probe item from `responding` to `pending` with `handler_timeout`
  - concurrent `respond` probes accepted exactly one request and rejected the rest as `not_pending`
  - deterministic local runtime probe returned the literal `lock_conflict` rejection while the item lock was pre-held
- re-sequenced the program after user direction:
  - inserted `TI1A` between `TI1` and `TI2`
  - made the local pytest harness and targeted backend tests mandatory before UI or package migration
- implemented and validated the full local test harness:
  - added `requirements_test.txt` pinned to `pytest-homeassistant-custom-component==0.13.205`
  - added `pytest.ini`
  - added repo-local venv workflow using `.venv-tinbox` and `.uv-cache`
  - added operator commands:
    - `npm run tinbox:test:setup`
    - `npm run tinbox:test`
  - added targeted tests under `tests/components/tunet_inbox/`
  - passed:
    - `npm run tinbox:check`
    - `npm run tinbox:test:setup`
    - `npm run tinbox:test`
- performed the Tunet control-point review for inbox frontend work, then deferred it when the program was re-sequenced backend-first
- inserted `TI1B` so the integration can be productized before any inbox surface work begins
- completed `TI1B` by:
  - moving runtime ownership to a single config entry
  - converting YAML bootstrap into import-only setup
  - adding `config_flow.py`
  - adding `diagnostics.py`
  - adding `translations/en.json`
  - removing the tracked UTC warning
  - proving live imported config-entry creation on the HA host
- promoted a new backend-only `TI1C` because the integration still logs-and-skips malformed persisted items instead of quarantining and surfacing them

## Current Contract Assumptions

- dashboard ingress must go through `tunet_inbox.respond`
- canonical business event is `tunet_inbox_action`
- queue refresh event is `tunet_inbox_updated`
- raw mobile action format is `TINBOX|<item_id>|<action_id>`
- queue items are governed objects, not arbitrary JSON blobs
- action payloads are identifiers and render metadata only
- malformed persisted payloads must be quarantined and surfaced, not silently skipped

## Next Highest-Value Work

1. implement `TI1C`:
   - quarantine malformed persisted active/archive items during restore
   - surface a repair issue when quarantine is non-empty
   - expose quarantine state safely through diagnostics
   - add one governed local release-verification command
2. keep `TI2` deferred until `TI1C` closes
3. do not start OAL or Sonos package migration yet

## Deployment Notes

- this worktree does not currently contain a checked-in `.env`
- deploy scripts must therefore support:
  - local `.env` in the current worktree when present
  - fallback to the primary repo root `.env`
- backend deploy must treat Python changes as `HA RESTART`
- latest live proof used:
  - remote host `10.0.0.21`
  - config backup under `Backups/tunet_inbox/`
  - successful smoke target `http://10.0.0.21:8123`
  - imported config-entry proof:
    - count `1`
    - source `import`
    - title `Tunet Inbox`

## Risks / Watchpoints

- the next tranche must not reopen backend contract work unless a real UI integration blocker appears
- package migrations are currently the largest regression risk; do not start them before service semantics are stable
- do not let the Tunet card set the backend contract by accident
- keep receipts and clears explicit; do not overload the queue with informational notifications
- do not silently change action identifiers once package migrations start
