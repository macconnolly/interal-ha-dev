# Tunet Inbox - Implementation Plan

Working branch: `tunet/inbox-integration`  
Last updated: 2026-04-06  
Scope root: `/home/mac/HA/implementation_10/.claude/worktrees/tunet-inbox-integration/custom_components/tunet_inbox`

## Mission

Build `tunet_inbox` as the governed notification-control plane for actionable Home Assistant notifications:

- canonical queue and action arbiter
- governed service and event contract
- mobile + dashboard parity
- deterministic clear and resolve ownership
- migration path for OAL and Sonos flows

## Program Authorities

- execution policy:
  - `custom_components/tunet_inbox/AGENTS.md`
- normalized cross-tranche status authority:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- active execution authority:
  - the current tranche doc under `custom_components/tunet_inbox/Docs/tranches/`
- session continuity:
  - `custom_components/tunet_inbox/handoff.md`
- interpretation/change log:
  - `custom_components/tunet_inbox/FIX_LEDGER.md`

## Execution Control Policy

- `plan.md` governs program order, tranche queue, dependencies, and gates.
- No tranche is executable until it has a fully filled tranche spec under `Docs/tranches/`.
- Default execution mode is correct for implementation inside an approved tranche.
- Explicit planning mode is required only when:
  - a new tranche starts
  - a public contract changes
  - allowed-file boundaries are exceeded
  - deploy/restart/rollback sequencing becomes ambiguous
  - ownership or acceptance criteria are unclear
- We do not stop for planning mode on every narrow fix that already fits the active tranche.

## Locked Product Direction

- `tunet_inbox` is the canonical queue and action arbiter.
- The dashboard is a renderer/requester only.
- Mobile notifications remain a delivery surface, not the source of truth.
- OAL and Sonos continue to decide what actions mean and when conditions are valid.
- `tunet_inbox` owns:
  - queue persistence
  - action validation
  - response locks
  - canonical event emission
  - queue refresh signaling
  - mobile send/clear orchestration
  - audit metadata
  - startup reconcile and stale recovery

## Active Contract Decisions

- Public services:
  - `tunet_inbox.post`
  - `tunet_inbox.respond`
  - `tunet_inbox.resolve`
  - `tunet_inbox.fail`
  - `tunet_inbox.dismiss`
  - `tunet_inbox.list_items`
- Public events:
  - `tunet_inbox_action`
  - `tunet_inbox_updated`
- Identity:
  - `key` = logical notification identity
  - `item_id` = active instance identity
- Raw mobile action format:
  - `TINBOX|<item_id>|<action_id>`
- Default queue policies:
  - `max_pending_items = 64`
  - `response_timeout_seconds = 30`
  - `archive_retention_days = 3`
- Queue is not a permanent history.
- Manual dismiss exists but is not exposed by default in the card.

## Program Order

The `tunet_inbox` workstream executes in this order:

1. `TI0` governance scaffold, backend skeleton, operator path
2. `TI1` service pipeline and storage enforcement
3. `TI1A` local HA integration test harness
4. `TI1B` integration productization and supportability
5. `TI1C` corruption quarantine, repairs, and release verification
6. `TI2` Tunet inbox card and dashboard surfaces
7. `TI3` OAL pilot migration
8. `TI4` Sonos pilot migration
9. `TI5` TV/timer/confirmable expansion
10. `TI6` diagnostics, repairs, corruption handling, rollout hardening

Do not skip ahead. The backend contract must be stable before migrating package logic or widening UI scope.
The only intentional exception is that supportability work may be pulled forward ahead of UI when the backend still violates a locked governance rule.

## Tranche Dependency Rules

- `TI1` cannot start until `TI0` is closed.
- `TI1A` cannot start until `TI1` is closed.
- `TI1B` cannot start until `TI1A` is closed.
- `TI1C` cannot start until `TI1B` is closed.
- `TI2` cannot start until `TI1C` is closed.
- `TI3` cannot start until both `TI1C` and `TI2` are closed.
- `TI4` cannot start until `TI3` is closed.
- `TI5` cannot start until both `TI3` and `TI4` are closed.
- `TI6` cannot start until `TI5` is closed unless an emergency supportability blocker forces an exception.

## Tranche Entry And Exit Model

### Entry criteria

A tranche is allowed to move from `PLANNED` to `IN PROGRESS` only when:

- all hard dependencies are closed
- its tranche doc exists and is fully filled
- the normalized open issues it is meant to close are explicitly listed in `execution_ledger.md`
- the file boundary is frozen
- validation and deploy impact are already defined

### Exit criteria

A tranche is allowed to move to `DONE` only when:

- its acceptance criteria are implemented
- required docs sync is complete
- all required static validation has passed
- any required runtime validation has passed
- any required HA/live validation has passed, if that tranche requires live proof
- the ledger and handoff reflect the new normalized state

### Promotion rule

The next tranche does not become active merely because coding finished in the previous tranche.
Promotion requires the prior tranche to be explicitly closed against its exit criteria.

## Current Tranche

- active tranche:
  - `TI1C — Corruption Quarantine, Repairs, And Release Verification`
  - `ACTIVE`
  - integration work is backend-only in this tranche
  - no `Dashboard/Tunet/**` implementation is authorized until `TI1C` closes

## Tranche Queue

### TI0 — Governance Scaffold + Core Backend Skeleton

- status:
  - `DONE`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI0_governance_scaffold_core_backend_skeleton.md`
- purpose:
  - create the governed backend workstream, operator path, YAML bootstrap, and validation base
- entry gate:
  - satisfied
- exit gate:
  - `TINBOX-GOV-3`, `TINBOX-BE-1`, `TINBOX-BE-2`, and `TINBOX-BE-3` are closed
- deploy impact:
  - `HA RESTART`

### TI1 — Service Pipeline And Storage Enforcement

- status:
  - `DONE`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI1_service_pipeline_and_storage_enforcement.md`
- purpose:
  - finalize governed service semantics, state transitions, dedupe behavior, timeout recovery, and live service proof
- cannot start until:
  - satisfied
- must close before:
  - `TI2`
  - `TI3`
- exit gate:
  - `TINBOX-TI1-1`, `TINBOX-TI1-2`, and the first recorded deploy/smoke proof are closed
- deploy impact:
  - `HA RESTART`

### TI1A — Local HA Integration Test Harness

- status:
  - `DONE`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI1A_local_ha_integration_test_harness.md`
- purpose:
  - add a local Home Assistant custom-integration pytest harness, operator scripts, and the first targeted backend tests for manager state transitions, service responses, and event emission
- cannot start until:
  - `TI1` closes
- must close before:
  - `TI2`
  - `TI3`
- exit gate:
  - `TINBOX-TEST-1` and `TINBOX-TEST-2` are closed
- deploy impact:
  - `REPO ONLY`

### TI1B — Integration Productization And Supportability

- status:
  - `DONE`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI1B_integration_productization_and_supportability.md`
- purpose:
  - finish the backend integration shape before any dashboard work by adding config-entry setup, diagnostics, translation-backed UI strings, manifest hardening, and supportability tests
- cannot start until:
  - `TI1A` closes
- must close before:
  - `TI2`
  - `TI3`
- exit gate:
  - `TINBOX-PROD-1` and `TINBOX-PROD-2` are closed
- deploy impact:
  - `HA RESTART`

### TI1C — Corruption Quarantine, Repairs, And Release Verification

- status:
  - `ACTIVE`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI1C_corruption_quarantine_repairs_and_release_verification.md`
- purpose:
  - finish the backend production hardening gap by quarantining malformed persisted payloads, surfacing repair issues, and adding one governed release-verification path before any UI work starts
- cannot start until:
  - `TI1B` closes
- must close before:
  - `TI2`
  - `TI3`
- exit gate:
  - `TINBOX-PROD-3` and `TINBOX-PROD-4` are closed
- deploy impact:
  - `HA RESTART`

### TI2 — Tunet Inbox Card Rehab Surface

- status:
  - `PLANNED`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI2_tunet_inbox_card_rehab_surface.md`
- purpose:
  - build the governed Tunet inbox card and the dedicated validation/dashboard surfaces
- cannot start until:
  - `TI1C` closes
- must close before:
  - `TI3`
- exit gate:
  - `TINBOX-UI-1` and `TINBOX-UI-2` are closed
- deploy impact:
  - `HA RESOURCE UPDATE`
  - `HA DASHBOARD UPDATE`

### TI3 — OAL Pilot Migration

- status:
  - `PLANNED`
- tranche doc:
  - `custom_components/tunet_inbox/Docs/tranches/TI3_oal_pilot_migration.md`
- purpose:
  - migrate OAL override reminder and override-expiring flows onto the governed inbox path end-to-end
- cannot start until:
  - `TI1C` closes
  - `TI2` closes
- must close before:
  - `TI4`
  - `TI5`
- exit gate:
  - `TINBOX-OAL-1` and `TINBOX-OAL-2` are closed
- deploy impact:
  - `HA PACKAGE RELOAD`
  - `HA RESTART` only if integration code changes at the same time

### TI4 — Sonos Pilot Migration

- status:
  - `PLANNED`
- purpose:
  - migrate Sonos alarm playing onto the inbox path
- cannot start until:
  - `TI3` closes
- exit gate:
  - `TINBOX-SONOS-1` is closed
- deploy impact:
  - `HA PACKAGE RELOAD`

### TI5 — TV / Timer / Confirmable Expansion

- status:
  - `PLANNED`
- purpose:
  - migrate remaining OAL TV/timer flows and Sonos confirmable flows
- cannot start until:
  - `TI3` closes
  - `TI4` closes
- exit gate:
  - `TINBOX-EXP-1` is closed
- deploy impact:
  - `HA PACKAGE RELOAD`

### TI6 — Hardening

- status:
  - `PLANNED`
- purpose:
  - diagnostics, repairs, corruption handling, pruning policy, and supportability hardening
- cannot start until:
  - `TI5` closes
- exit gate:
  - `TINBOX-HARDEN-1` is closed
- deploy impact:
  - `HA RESTART`

## Governance Backlog

- add malformed-item quarantine and repair issue creation for storage corruption
- add one release-verification command that runs the governed backend quality gate locally
- add package deploy helper when OAL/Sonos tranche begins

## Program-Level Acceptance Gates

### TI0 gate

- governance docs exist and are internally consistent
- program ledger exists and is normalized enough to own cross-tranche issue state
- `TI1`, `TI2`, and `TI3` tranche docs exist
- `npm run tinbox:check`, `npm run tinbox:deploy:integration`, and `npm run tinbox:smoke` exist in `package.json`
- backend scaffold files load statically
- YAML bootstrap config is wired

### TI1 gate

- `post`, `respond`, `resolve`, `fail`, `dismiss`, and `list_items` are registered in HA
- storage persists and restores queue items
- stale or duplicate responses are rejected deterministically
- canonical events fire once per accepted response
- timeout recovery behavior is proven

### TI1B gate

- single config-entry runtime exists and is importable from YAML bootstrap
- diagnostics redact queue-sensitive fields
- config/options flow strings exist and load
- manifest metadata is valid for the supported runtime shape
- local pytest suite passes without the tracked UTC warning

### TI1C gate

- malformed persisted queue payloads are quarantined instead of skipped silently
- a repair issue is raised when quarantine is non-empty and clears when the condition is gone
- diagnostics expose quarantine state without leaking sensitive payload content
- one governed local release-verification command passes
- post-deploy smoke still passes after the quarantine/repairs changes

### TI2 gate

- card loads items through `list_items`
- card refreshes on `tunet_inbox_updated`
- card never calls package services directly
- rehab dashboard and standalone inbox dashboard both render the card successfully

### TI3 gate

- OAL override reminder and override-expiring use `tunet_inbox.post`
- phone and dashboard both route through `tunet_inbox_action`
- natural resolution clears queue + phone prompt
- stale or double responses are rejected safely

## External Planning Tracker

The old dashboard-centric enhancement artifact is no longer the right planning shape for this work.
The replacement tracker authority is:

- `HA-References/tunet_inbox_enhancement_matrix.md`

The legacy file should be treated as superseded once the replacement is in place.

## Out Of Scope For The Current Active Tranche

- Tunet card runtime
- dashboard YAML
- OAL package migration
- Sonos package migration
- any widening of the public service or event contract
