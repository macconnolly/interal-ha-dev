# Tunet Inbox Fix Ledger

Working branch: `tunet/inbox-integration`  
Last updated: 2026-04-06

## Session Delta (2026-04-06, TI0 — Governance Scaffold)

Change marker: establish a local governed workstream before implementation widens into backend services, UI, or package migrations

- `CHOSEN INTERPRETATION`
  - user required the inbox work to be tranchable and governed similarly to the Tunet dashboard program
  - chosen implementation:
    - give `tunet_inbox` its own scoped `AGENTS.md`
    - create a local `plan.md`, `handoff.md`, and `FIX_LEDGER.md`
    - create explicit contract and deploy/test docs under `custom_components/tunet_inbox/Docs/`
    - make deploy/check/smoke capability part of tranche zero rather than an afterthought
- `RESULT`
  - the backend now has a local execution authority
  - later service/event/item contract changes will have a dedicated place to be recorded
  - package migrations and Tunet UI work can now reference a stable backend ledger instead of broad chat context

## Session Delta (2026-04-06, TI0 — Tranche Hardening)

Change marker: convert `TI0` from a broad active intention into a fully specified execution tranche and lock the planning-mode policy

- `CHOSEN INTERPRETATION`
  - the top-level program plan is necessary but not sufficient for safe execution
  - chosen implementation:
    - create a full tranche doc for `TI0`
    - make tranche docs mandatory before execution
    - document when explicit planning mode is required versus when default execution should continue
- `RESULT`
  - `TI0` can now be reviewed and executed against exact file boundaries, validation, stop conditions, and rollback
  - future tranches have a clear governance pattern to follow instead of relying on implicit chat agreement

## Session Delta (2026-04-06, Program Ledger Alignment)

Change marker: add a program-level ledger equivalent to Tunet's `visual_defect_ledger.md`

- `CHOSEN INTERPRETATION`
  - this project needs a normalized status surface above the tranche docs, not just a plan and handoff
  - chosen implementation:
    - create `custom_components/tunet_inbox/Docs/execution_ledger.md`
    - treat it as the cross-tranche normalized backlog and status authority for the inbox project
    - add it to the local governance review pack and precedence chain
- `RESULT`
  - `tunet_inbox` now has:
    - a program plan
    - a program ledger
    - tranche specs
    - session continuity docs
  - issue tracking can now stay normalized across backend, UI, OAL, Sonos, and rollout work

## Session Delta (2026-04-06, Planning Layer Deepening)

Change marker: harden the normalized planning layer from minimal governance into production-grade execution planning

- `CHOSEN INTERPRETATION`
  - the user wanted planning to start from the missing middle layer, not from more backend code
  - chosen implementation:
    - expand `execution_ledger.md` into the normalized issue authority
    - deepen `plan.md` with tranche dependencies, entry/exit gates, and program control rules
    - author full tranche specs for `TI1`, `TI2`, and `TI3`
    - replace the stale enhancement tracker with an inbox-specific enhancement matrix
- `RESULT`
  - the project now has a complete planning stack:
    - policy
    - program plan
    - normalized ledger
    - tranche execution docs
    - continuity docs
    - enhancement decision matrix
- the next implementation step can proceed without reopening planning ambiguity

## Session Delta (2026-04-06, TI0 Closeout And TI1 Activation)

Change marker: close the repo-only TI0 blockers on evidence and begin the first live backend-proof tranche

- `CHOSEN INTERPRETATION`
  - TI0 could be closed once its stated exit gate was met even though the first live smoke proof remained open
  - chosen implementation:
    - close TI0 on package wiring, local YAML bootstrap, and static validation evidence
    - promote TI1 as the active tranche for runtime and HA/live proof
- `RESULT`
  - `package.json` now exposes the governed `tinbox:*` operator commands
  - local `Configuration/configuration.yaml` now contains the `tunet_inbox:` bootstrap block and logger entries
  - static validation passed and TI0 can be treated as closed in the normalized ledger

## Session Delta (2026-04-06, TI1 Contract Enforcement And Live Proof)

Change marker: align the runtime with the written contract, harden the deploy path, and record first HA/live service proof

- `CHOSEN INTERPRETATION`
  - the existing runtime had real contract mismatches:
    - titles were being validated as safe IDs
    - helper-driven mobile targeting was treated like a direct notify service
    - dismiss did not clear the matching mobile prompt
    - the deploy helper could not safely sync required YAML bootstrap because local and remote `configuration.yaml` had diverged
  - chosen implementation:
    - treat render text as free text while keeping identifiers strict
    - resolve helper-driven defaults into `notify.mobile_app_<device_id>`
    - make `dismiss` clear the matching mobile tag when configured
    - emit queue refresh when timeout recovery returns an item to `pending`
    - patch only the governed `tunet_inbox` fragments into remote `configuration.yaml` instead of overwriting the full file
- `RESULT`
  - HA logs show `tunet_inbox` loading successfully on the live instance
  - smoke now passes against `/api/services`
  - live service probes proved:
    - `post`
    - `list_items`
    - `respond`
    - `fail`
    - `resolve`
    - `dismiss`
  - live rejection proofs now exist for:
    - `item_not_found`
    - `invalid_action`
    - `expired`
    - `not_pending`
  - timeout recovery is now live-proven:
    - a probe item returned from `responding` to `pending`
    - `last_error` was set to `handler_timeout`
  - concurrent response proof is now live-proven:
    - exactly one response was accepted
    - competing responses were rejected as `not_pending`
- remaining TI1 gap is explicit:
  - the direct `lock_conflict` branch still needs a documented acceptance decision or a later deterministic harness

## Session Delta (2026-04-06, TI1 Closure And Test-Harness Resequencing)

Change marker: close the remaining TI1 evidence gap and insert a dedicated backend regression tranche before any UI or package migration

- `CHOSEN INTERPRETATION`
  - the deterministic runtime probe is sufficient to close the literal `lock_conflict` branch because it exercises the exact manager path with the per-item lock pre-held
  - the user then explicitly prioritized a real local HA integration test harness with `pytest-homeassistant-custom-component` before frontend or package work
  - chosen implementation:
    - treat `TI1` as closed
    - insert a new tranche `TI1A` between `TI1` and `TI2`
    - make local pytest harness work and targeted backend tests a hard dependency for UI and migration tranches
- `RESULT`
  - the program order now requires backend regression coverage before the Tunet card or OAL/Sonos migration can advance
  - `TINBOX-TI1-2` can be closed on deterministic runtime evidence
  - new owned issues are:
    - `TINBOX-TEST-1`
    - `TINBOX-TEST-2`

## Session Delta (2026-04-06, TI1A Test Harness Implementation)

Change marker: implement the local HA custom-integration test harness and close the backend regression tranche on passing evidence

- `CHOSEN INTERPRETATION`
  - the fastest acceptable local workflow is a repo-local venv plus `pytest-homeassistant-custom-component`, not a devcontainer-first setup
  - the latest package release visible from the local Python index was not usable:
    - the newest GitHub release required Python 3.14
    - the current Python 3.12-compatible index head was `0.13.205`
  - chosen implementation:
    - pin `pytest-homeassistant-custom-component==0.13.205`
    - use `uv` with a repo-local cache and repo-local venv
    - add operator scripts and npm wiring for setup and execution
    - add HA-style tests under `tests/components/tunet_inbox/`
- `RESULT`
  - `TI1A` acceptance is now satisfied
  - backend regression coverage now exists for:
    - manager state transitions
    - service responses
    - canonical event emission
  - one known warning remains visible and tracked:
    - `datetime.utcnow()` deprecation in `utcnow_iso()`

## Session Delta (2026-04-06, TI1B insertion And TI2 Deferral)

Change marker: user re-sequenced the program to finish productizing the integration before starting any Tunet inbox surface

- `CHOSEN INTERPRETATION`
  - the backend now exists and is tested, but it is not yet “integration-finished”
  - the concrete gaps are:
    - no config-entry setup path
    - no diagnostics surface
    - no translation-backed config UX
    - placeholder manifest metadata and a tracked Python 3.12 warning
  - chosen implementation:
    - insert `TI1B` between `TI1A` and `TI2`
    - demote `TI2` back to `READY TO START`
    - return Tunet root docs to their normal `CD9` state because no Tunet implementation is active now
- `RESULT`
  - the active tranche is backend-only again
  - no `Dashboard/Tunet/**` edits are authorized until `TI1B` closes
  - `TI2` remains the next UI control point after integration productization

## Session Delta (2026-04-06, TI1B implementation And TI1C promotion)

Change marker: close the integration-productization tranche on evidence, then immediately open a narrower backend hardening tranche for the remaining production blocker

- `CHOSEN INTERPRETATION`
  - `TI1B` is complete because the originally declared supportability gaps are now closed:
    - single config-entry runtime exists
    - YAML bootstrap imports into that runtime
    - diagnostics exist
    - translation-backed config/options strings exist
    - placeholder manifest metadata is gone
    - the tracked UTC warning is fixed
  - however, the backend still violates a locked governance rule:
    - malformed persisted queue items are logged and skipped instead of logged and quarantined
  - chosen implementation:
    - close `TI1B` on local and HA/live evidence
    - insert `TI1C` before any UI work
    - make quarantine, repair surfacing, and one governed release-verification path the next active backend-only tranche
- `RESULT`
  - the backend integration is now productized enough to be configured and supported in HA
  - the remaining blocker before UI work is explicit, narrow, and governance-driven
  - `TI2` is no longer the immediate next action; `TI1C` is

## Session Delta (2026-04-06, TI1B implementation Evidence Pack)

Change marker: record the concrete implementation and evidence that closed the productization tranche

- `IMPLEMENTATION`
  - runtime ownership moved to a single config entry in `__init__.py`
  - YAML bootstrap now imports into that config entry instead of instantiating a parallel runtime
  - `config_flow.py` and `translations/en.json` provide config/options flow UX
  - `diagnostics.py` exports redacted integration state
  - `manager.py` now exposes restore/config snapshots for diagnostics
  - `services.py` now resolves the active manager through the config-entry-owned runtime
  - `manifest.json` now reflects the config-flow runtime shape and no longer carries placeholder URLs
  - `utcnow_iso()` now uses timezone-aware UTC and no longer emits the tracked Python 3.12 warning
  - new HA-style tests were added for:
    - config flow
    - YAML import path
    - diagnostics redaction
- `EVIDENCE`
  - local:
    - `npm run tinbox:check`
    - `npm run tinbox:test`
    - `10 passed`
  - live:
    - `npm run tinbox:deploy:integration`
    - `ha_check_config() -> valid`
    - `ha_restart(confirm=true)`
    - post-restart `npm run tinbox:smoke`
    - remote config-entry proof from `/config/.storage/core.config_entries`:
      - exactly one `tunet_inbox` entry
      - source `import`
      - title `Tunet Inbox`

## Session Delta (2026-04-06, TI1C implementation And Closeout)

Change marker: close the remaining backend production blocker before any UI tranche starts

- `CHOSEN INTERPRETATION`
  - the remaining blocker after `TI1B` was not UI work, but backend governance:
    - malformed persisted items were still being logged and skipped
  - chosen implementation:
    - add a persisted quarantine collection
    - surface restore corruption through Repairs
    - extend diagnostics with redacted quarantine visibility
    - add one governed local release-verification command
- `RESULT`
  - malformed restored active and archive items are now quarantined instead of disappearing silently
  - the backend now raises a persistent Repair issue when quarantine is present
  - one operator command now proves the local backend release gate:

## Session Delta (2026-04-06, TI1D live pilot blockers)

Change marker: live TI1D proof exposed two real production blockers that were not visible in local tests

- `CHOSEN INTERPRETATION`
  - the notify-group contract itself is sound, but the imported config-entry runtime can still boot with stale option values that override the newly imported YAML defaults
  - the OAL override-reminder pilot is materially correct in structure, but its `expires_at` template currently emits a value marked as UTC while being derived from local time
  - chosen implementation:
    - widen `TI1D` just enough to include `config_flow.py`
    - make the YAML import path authoritative over stale overlapping options for import-sourced entries
    - correct the pilot OAL expiry template to emit a true UTC timestamp
- `RESULT`
  - the remaining TI1D work is now concrete and bounded by live evidence rather than guesswork
  - the next deploy/restart cycle will prove both operator routing and the first real OAL action path under the intended notify-group target
    - `tinbox:check`
    - `tinbox:test`
    - `tinbox:probe:runtime`
  - `TI1C` is closed on local and HA/live evidence
  - the integration is now backend-prod-ready; the next control point is UI work, not more backend reshaping

## Session Delta (2026-04-06, TI1D exception tranche — API-first pilot before Tunet UI)

Change marker: user asked for real API testing with the HA token and a minimal way to exercise a migrated notification before building Tunet UI

- `CHOSEN INTERPRETATION`
  - the user does not want to jump into Tunet yet
  - a narrow exception tranche is justified because:
    - HA REST service calls with `return_response` are already working against the live instance
    - one real migrated flow can be exercised through `tunet_inbox.respond`
    - a plain Lovelace service-button harness becomes viable if the service layer supports `key` as well as `item_id`
  - chosen implementation:
    - insert `TI1D` before `TI2`
    - keep the tranche strictly non-Tunet
    - migrate only the OAL override reminder flow
    - add a token-backed API probe script using `.env`
- `RESULT`
  - we can prove one live notification flow end to end without waiting for the inbox card
  - `TI2` remains future UI work, not a prerequisite for this operator/API slice

## Session Delta (2026-04-06, Notify target contract clarification)

Change marker: resolve the lingering ambiguity between helper-driven routing and explicit notify-service routing

- `CHOSEN INTERPRETATION`
  - the runtime already supports both:
    - helper-backed routing via `input_text.*`
    - direct `notify.*` routing
  - the ambiguity was documentation and config UX wording, not a missing runtime capability
  - chosen implementation:
    - keep the stored config key as `notify_device_helper` for compatibility
    - clarify in active docs and config UX that the value may be either a helper entity or a direct `notify.*` service
    - state explicitly that blank routing is invalid and does not imply broadcast
    - recommend notify groups, not `notify.notify`, for multi-device delivery
- `RESULT`
  - the operator contract now matches the actual backend behavior
  - multi-device delivery has a deterministic documented path
  - future package migrations do not need to guess what blank routing means

## Open Items

- `TI1D` is active
- add key-addressable item references to the backend service/operator path
- add token-backed HA API probe coverage
- migrate OAL override reminder as the single pre-UI pilot
- package migrations remain blocked until `TI2` is explicitly closed
