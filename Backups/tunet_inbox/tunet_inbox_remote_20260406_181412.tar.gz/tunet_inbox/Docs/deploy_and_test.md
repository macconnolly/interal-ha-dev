# Tunet Inbox Deploy And Test

## Architecture

```
Source:    custom_components/tunet_inbox/*.py
Docs:      custom_components/tunet_inbox/{plan.md,handoff.md,FIX_LEDGER.md}
Deploy:    /config/custom_components/tunet_inbox/
Bootstrap: targeted patch of /config/configuration.yaml for tunet_inbox YAML + logger wiring
Smoke:     HA REST service discovery + optional service invocation
```

`tunet_inbox` is a backend integration, so there is no frontend build step.
Instead, the governed workflow is:

1. static check
2. deploy integration files
3. restart HA if Python changed
4. smoke-check service registration
5. only then widen to package or UI changes

## npm Scripts

| Script | Command | Purpose |
|--------|---------|---------|
| `tinbox:check` | `bash custom_components/tunet_inbox/scripts/check_tunet_inbox.sh` | Static validation for backend files and tied YAML |
| `tinbox:deploy:integration` | `bash custom_components/tunet_inbox/scripts/deploy_tunet_inbox.sh` | Backup + deploy the integration files and patch governed config bootstrap on HA |
| `tinbox:test:setup` | `bash custom_components/tunet_inbox/scripts/setup_tunet_inbox_test_env.sh` | Create/update the repo-local Python test venv and install pinned HA custom-integration test deps |
| `tinbox:test` | `bash custom_components/tunet_inbox/scripts/run_tunet_inbox_pytest.sh` | Run the targeted local pytest suite under `tests/components/tunet_inbox/` |
| `tinbox:probe:runtime` | `python3 custom_components/tunet_inbox/scripts/tunet_inbox_runtime_probe.py lock-conflict` | Deterministic local runtime proof for the literal `lock_conflict` manager branch |
| `tinbox:smoke` | `node custom_components/tunet_inbox/scripts/tunet_inbox_smoke.mjs` | Verify `tunet_inbox` services exist in HA |

## Environment Resolution

The worktree may not contain a local `.env`.

Deploy and smoke scripts must therefore resolve environment in this order:

1. `<current worktree>/.env`
2. `/home/mac/HA/implementation_10/.env`

Required values:
- `HA_SSH_HOST`
- `HA_SSH_USER`
- `HA_SSH_PASSWORD`
- `HA_LONG_LIVED_ACCESS_TOKEN` or `HA_TOKEN`

Optional values:
- `HA_URL`

If `HA_URL` is absent, derive:
- `http://${HA_SSH_HOST}:8123`

## Static Validation

`tinbox:check` must:

- run `python3 -m py_compile` over `custom_components/tunet_inbox/*.py`
- run `python3 -m py_compile` over `tests/components/tunet_inbox/*.py`
- run `bash -n` over the inbox shell scripts
- parse `Configuration/configuration.yaml` if touched
- verify the governance docs exist
- fail fast with a non-zero exit code

## Local Test Harness

### Layout

The local inbox suite follows Home Assistant-style test structure:

```text
tests/
  conftest.py
  components/
    tunet_inbox/
      conftest.py
      test_events.py
      test_manager.py
      test_services.py
```

### Dependency policy

- the local harness is pinned through `requirements_test.txt`
- the current compatible pin is:
  - `pytest-homeassistant-custom-component==0.13.205`
- this pin was selected because it resolves under the local Python 3.12 toolchain

### Venv and cache policy

- local test venv:
  - `.venv-tinbox/`
- local uv cache:
  - `.uv-cache/`
- both are repo-local and ignored by git

### Setup and execution

```bash
npm run tinbox:test:setup
npm run tinbox:test
```

`tinbox:test:setup` must:

1. use the concrete local `python3` path
2. create or replace `.venv-tinbox`
3. use the repo-local `.uv-cache`
4. install the pinned test requirements

`tinbox:test` must:

1. fail fast if `.venv-tinbox` is missing
2. export `PYTHONPATH` to the repo root
3. run only `tests/components/tunet_inbox/`

## Deploy Workflow

### Integration deploy

```bash
npm run tinbox:deploy:integration
```

This must:

1. resolve `.env`
2. back up the remote `/config/custom_components/tunet_inbox/` into a local timestamped backup folder
3. back up the remote `/config/configuration.yaml`
4. patch the remote `/config/configuration.yaml` idempotently so it contains:
   - the `tunet_inbox:` bootstrap block
   - logger entries for `custom_components.tunet_inbox`
5. create the remote directory if missing
6. copy the integration files to `/config/custom_components/tunet_inbox/`
7. print the required restart instruction

### Configuration patch rule

The deploy helper must not blindly overwrite the full remote `configuration.yaml`.

Reason:
- the live HA host may legitimately contain dashboard/resource entries that are newer than the local repo snapshot
- full-file overwrite would create unrelated regression risk

Required behavior:
- patch only the governed `tunet_inbox:` bootstrap block and its logger entries
- make the patch idempotent
- back up the full remote file before any mutation

### Restart policy

If Python integration files changed:
- restart Home Assistant

If only docs changed:
- no HA action required

If only package YAML changes later:
- use the package deploy/reload flow for that tranche

## Smoke Workflow

```bash
npm run tinbox:smoke
```

The smoke script must:

1. resolve `.env`
2. call `GET /api/services`
3. verify the `tunet_inbox` domain exists
4. verify these services exist:
   - `post`
   - `respond`
   - `resolve`
   - `fail`
   - `dismiss`
   - `list_items`

If any are missing, the smoke script must fail with a non-zero exit code.

## Rollback

Small rollback path:

1. copy the latest local backup of `/config/custom_components/tunet_inbox/` back to the HA host
2. if the bootstrap patch caused regressions, restore the latest local backup of `/config/configuration.yaml`
3. restart HA
4. re-run `npm run tinbox:smoke`

## Acceptance Expectations

The backend is not “deployed” just because files copied successfully.
Minimum deploy acceptance:

- static check passed
- files copied
- HA restarted when required
- smoke check passed
