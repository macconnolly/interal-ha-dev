# Tunet Inbox Handoff

Last updated: 2026-04-17 (America/Denver)  
Working branch: `tunet/inbox-integration`

## Current State

- `tunet_inbox` backend is live and governed from `custom_components/tunet_inbox/`.
- Closed tranches:
  - `TI0`
  - `TI1`
  - `TI1A`
  - `TI1B`
  - `TI1C`
  - `TI1D`
  - `TI1E`
  - `TI2`
  - `TI2A`
- Active next tranche:
  - `custom_components/tunet_inbox/Docs/tranches/TI2B_mobile_url_public_service_schema_parity.md`
  - status: `READY TO START`
- No `Dashboard/Tunet/**` tranche is active.
- `TI3` remains blocked until `TI2B` closes.
- The next implementation phase is a narrow backend contract-control tranche to unblock `mobile.url` in the public `tunet_inbox.post` service schema.

## Latest Proven State

- Backend:
  - `npm run tinbox:check`
  - `npm run tinbox:test`
  - `npm run tinbox:smoke`
  - `npm run tinbox:probe:api`
  - imported config entry is loaded with `options = {}`
  - notify routing is live through `notify.tunet_inbox_all_devices`
- Compare-mode package coverage:
  - OAL mirrored:
    - override reminder
    - override expiring
    - TV mode activated
    - TV mode prompt
    - bridge expiring
    - TV presence prompt
    - unified timer expiring
  - Sonos mirrored:
    - alarm playing
    - evening alarm check
    - Apple TV auto-off
- Inbox UI:
  - `custom:tunet-inbox-card` is live
  - rehab fixtures exist
  - standalone dashboard `tunet-inbox-yaml` is registered and reachable
- Mobile continuity:
  - direct iOS notifications still send
  - touched notifications body-tap to `/tunet-inbox-yaml/inbox`
  - touched confirmation receipts were removed
  - OAL TV prompt has a 5-minute debounce
  - `sensor.sonos_alarm_playing` no longer restores into a broken/unavailable state
- TI3 blocker proof:
  - live `tunet_inbox.post` without `mobile.url` succeeded
  - live `tunet_inbox.post` with `mobile.url` returned `400 Bad Request`
  - the OAL package was restored to safe compare-mode for the three TI3 flows and redeployed
  - `ha_check_config() -> valid`
  - `automation.reload` succeeded
  - `tunet_inbox.list_items` returned `total: 0` after probe cleanup

## Current Contract Assumptions

- dashboard ingress must go through `tunet_inbox.respond`
- canonical business event is `tunet_inbox_action`
- queue refresh event is `tunet_inbox_updated`
- raw mobile action format is `TINBOX|<item_id>|<action_id>`
- queue items are governed objects, not arbitrary JSON blobs
- action payloads are identifiers and render metadata only
- malformed persisted payloads must be quarantined and surfaced, not silently skipped
- default notify target may be either:
  - a helper entity containing a mobile-app device id
  - a direct `notify.*` service such as a notify group
- blank notify routing is invalid and does not mean “all devices”

## Known Gaps / Stubs

- `TI3` is blocked, so no OAL flow is inbox-authoritative in production yet.
- Compare-mode duplication still exists by design for all non-cutover flows.
- Sonos authoritative cutover has not started.
- Bridge-expiring, presence-loss, TV-mode-activated, and unified-timer OAL flows remain compare-mode only and are explicitly out of TI3 scope.
- The `tunet_inbox` public contract and live implementation are split on `mobile.url`:
  - `models.py` and `mobile.py` support it
  - `services.py` rejects it at the public service schema layer
- The next Codex session must not resume package-only TI3 work until that backend contract gap is addressed in a separately governed tranche.
- `services.yaml` does not yet expose `mobile.url` in the operator-facing `post` service docs.
- there is no service-boundary regression test yet proving that `tunet_inbox.post` accepts and persists `mobile.url`

## TI3 Frozen Cutover Set

- `oal_override_reminder`
- `oal_override_expiring:<zone>`
- `oal_tv_mode_prompt:living_room`

Everything else in OAL stays compare-mode for now.

## Next Highest-Value Work

1. execute `TI2B` to reconcile `mobile.url` across:
   - `Docs/contracts.md`
   - `services.py` public schema
   - `services.yaml`
   - service-boundary tests
   - live service validation/proof
2. close `TINBOX-CONTRACT-2`
3. restore `TI3` from `BLOCKED` to `READY TO START`
4. reattempt the frozen OAL authoritative cutover set

## Deployment Notes

- this worktree does not currently contain a checked-in `.env`
- deploy scripts must therefore support:
  - local `.env` in the current worktree when present
  - fallback to the primary repo root `.env`
- backend deploy must treat Python changes as `HA RESTART`
- package-only TI3 work should prefer package deploy/reload rather than unrelated backend restarts
- latest live proof used:
  - remote host `10.0.0.21`
  - config backup under `Backups/tunet_inbox/`
  - successful smoke target `http://10.0.0.21:8123`

## Risks / Watchpoints

- TI3 already exposed a real backend blocker; the next tranche must be backend-contract scoped, not package-only
- preserve the per-flow `action-ready` vs `mirror-only` classification during package cutover work
- keep receipts and clears explicit; do not overload the queue with informational notifications
- do not silently change action identifiers once package migrations start
- do not widen TI3 into bridge, presence-loss, or unified-timer migration unless a documented stop condition forces a new control point
