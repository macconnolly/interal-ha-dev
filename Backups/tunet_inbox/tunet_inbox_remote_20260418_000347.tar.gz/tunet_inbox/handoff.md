# Tunet Inbox Handoff

Last updated: 2026-04-06 (America/Denver)  
Working branch: `tunet/inbox-integration`

## Current State

- `tunet_inbox` is being introduced as a new governed custom integration.
- The workstream now has its own scoped execution contract under `custom_components/tunet_inbox/`.
- The program-level status ledger for the project is now:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- `TI0` is closed.
- `TI1` is closed.
- `TI1A` is closed.
- `TI1B` is closed.
- `TI1C` is closed.
- `TI1D` is closed.
- `TI1E` is closed.
- `TI2` is closed.
- Next promotion target:
  - `custom_components/tunet_inbox/Docs/tranches/TI3_oal_pilot_migration.md`
- No `Dashboard/Tunet/**` tranche is active in this branch right now.
- Compare-mode package translation is complete; no package tranche is active now.

## What Changed This Session

- created the local governance workstream
- fixed the contract source-of-truth location under `custom_components/tunet_inbox/`
- added an explicit planning-control rule:
  - use default execution inside an approved tranche
  - re-enter planning only at tranche or contract control points
- added the normalized program ledger:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- authored tranche specs for:
  - `TI1`
  - `TI2`
  - `TI3`
- replaced the stale dashboard-centric enhancement tracker with:
  - `HA-References/tunet_inbox_enhancement_matrix.md`
- closed the TI0 repo blockers by:
  - wiring `tinbox:*` commands into `package.json`
  - adding the local `tunet_inbox:` bootstrap block and logger wiring to `Configuration/configuration.yaml`
  - passing `py_compile`, `node --check`, and `npm run tinbox:check`
- patched the backend contract/runtime by:
  - allowing free-text titles and action titles
  - validating dashboard response sources explicitly
  - resolving helper-driven mobile targets to `notify.mobile_app_<device_id>`
  - clearing matching mobile notifications on `dismiss`
  - emitting queue refresh events when timeout recovery returns items to `pending`
  - logging malformed restore payload skips instead of silently dropping them
- hardened the deploy path by:
  - backing up remote `configuration.yaml`
  - patching only the governed `tunet_inbox` bootstrap/logger fragments on the live HA host
  - avoiding full-file overwrite of a diverged remote config
- recorded HA/live proof:
  - deploy completed
  - config check returned valid
  - HA restart succeeded
  - smoke passed
  - live service probes covered `post`, `list_items`, `respond`, `fail`, `resolve`, and `dismiss`
  - timeout recovery returned a probe item from `responding` to `pending` with `handler_timeout`
  - concurrent `respond` probes accepted exactly one request and rejected the rest as `not_pending`
  - deterministic local runtime probe returned the literal `lock_conflict` rejection while the item lock was pre-held
- re-sequenced the program after user direction:
  - inserted `TI1A` between `TI1` and `TI2`
  - made the local pytest harness and targeted backend tests mandatory before UI or package migration
- implemented and validated the full local test harness:
  - added `requirements_test.txt` pinned to `pytest-homeassistant-custom-component==0.13.205`
  - added `pytest.ini`
  - added repo-local venv workflow using `.venv-tinbox` and `.uv-cache`
  - added operator commands:
    - `npm run tinbox:test:setup`
    - `npm run tinbox:test`
  - added targeted tests under `tests/components/tunet_inbox/`
  - passed:
    - `npm run tinbox:check`
    - `npm run tinbox:test:setup`
    - `npm run tinbox:test`
- performed the Tunet control-point review for inbox frontend work, then deferred it when the program was re-sequenced backend-first
- inserted `TI1B` so the integration can be productized before any inbox surface work begins
- completed `TI1B` by:
  - moving runtime ownership to a single config entry
  - converting YAML bootstrap into import-only setup
  - adding `config_flow.py`
  - adding `diagnostics.py`
  - adding `translations/en.json`
  - removing the tracked UTC warning
  - proving live imported config-entry creation on the HA host
- promoted a new backend-only `TI1C` because the integration still logs-and-skips malformed persisted items instead of quarantining and surfacing them
- completed `TI1C` by:
  - adding persisted quarantine storage for malformed restored active/archive payloads
  - exposing quarantine counts and redacted quarantine samples through diagnostics
  - surfacing a persistent Repair issue when quarantine is non-empty
  - adding `npm run tinbox:verify` as the governed local release-verification gate
  - extending backend HA-style tests for quarantine and Repairs
  - re-deploying, restarting HA, and passing post-restart smoke
- promoted `TI1D` as a narrow exception tranche:
  - token-backed HA API probing from `.env`
  - key-addressable operator path for queue items
  - one real migrated OAL notification flow before Tunet UI exists

## Current Contract Assumptions

- dashboard ingress must go through `tunet_inbox.respond`
- canonical business event is `tunet_inbox_action`
- queue refresh event is `tunet_inbox_updated`
- raw mobile action format is `TINBOX|<item_id>|<action_id>`
- queue items are governed objects, not arbitrary JSON blobs
- action payloads are identifiers and render metadata only
- malformed persisted payloads must be quarantined and surfaced, not silently skipped
- the default notify target may be either:
  - a helper entity containing a mobile-app device id
  - a direct `notify.*` service such as a notify group
- blank notify routing is invalid and does not mean “all devices”

## What Changed This Session

- created the missing active tranche authority:
  - `custom_components/tunet_inbox/Docs/tranches/TI1D_api_probe_key_operator_flow_and_single_flow_oal_pilot.md`
- clarified the default notify-target contract across the active backend docs:
  - helper entity and direct `notify.*` services are both valid
  - blank routing is invalid
  - notify groups are the recommended multi-device path
- added backend tests proving:
  - direct `notify.*` passthrough
  - helper-to-`notify.mobile_app_*` resolution
  - blank target rejection
- added config-flow coverage proving a direct `notify.*` service can be stored as the integration default target
- deployed the hardened integration and the migrated OAL package from the worktree to the live HA host
- patched the live HA config to include `notify.tunet_inbox_all_devices`
- passed:
  - `ha_check_config()`
  - `npm run tinbox:smoke`
  - `npm run tinbox:probe:api`
- triggered the live OAL override-reminder pilot and proved the item appears through `tunet_inbox.list_items`
- proved live `tunet_inbox.respond` by `key` against the OAL pilot and verified the queue clears afterward
- fixed the OAL pilot `expires_at` bug by switching it to a real UTC `isoformat()` expression and reloading automations
- at that point, import-precedence remained unresolved and was carried as non-blocking debt pending the user’s next normal restart
- re-sequenced the next program step by user direction:
  - broad compare-mode translation now comes before UI work
  - the new active tranche is `TI1E`
  - `TI3` is now framed as authoritative OAL cutover, not first translation

## What Changed This Session

- verified the post-restart import-sourced `tunet_inbox` entry is now:
  - `loaded`
  - `source = import`
  - `options = {}`
- completed `TI1E` compare-mode package translation inside the worktree:
  - OAL mirrored flows:
    - override reminder
    - override expiring
    - TV mode activated
    - TV mode prompt
    - bridge expiring
    - TV presence prompt
    - unified timer expiring
  - Sonos mirrored flows:
    - alarm playing
    - evening alarm check
    - Apple TV auto-off
- preserved the legacy mobile writers and raw mobile handlers while adding queue shadow posts with `send_mobile: false`
- classified compare-mode flows:
  - `shadow + action-ready`
    - OAL override reminder
    - OAL override expiring
    - OAL TV family
    - OAL unified timer
    - Sonos alarm playing
  - `shadow + mirror-only`
    - Sonos evening alarm check
    - Sonos Apple TV auto-off
- fixed a real Sonos legacy defect discovered during proof:
  - when `input_text.notify_target_device_id` contained a raw 32-character mobile device id, the package built a non-existent `notify.mobile_app_<device_id>` action
  - the alarm send/receipt/clear path now falls back to `notify.tunet_inbox_all_devices` for that case
- recorded fresh live proofs after the user restart:
  - OAL TV-family:
    - `automation.oal_v14_tv_bridge_manager`
    - key `oal_bridge_expiring:living_room`
    - accepted `tunet_inbox.respond(action_id='OAL_BRIDGE_KEEP')`
    - queue cleared
  - OAL timer/expiry-family:
    - `automation.oal_v13_override_expiring_soon_warning`
    - key `oal_override_expiring:unknown`
    - accepted `tunet_inbox.respond(action_id='OAL_LET_EXPIRE')`
    - queue cleared
  - Sonos alarm playing:
    - `automation.sonos_alarm_playing_notification`
    - key `sonos_alarm_playing:unknown_speaker`
    - accepted `tunet_inbox.respond(action_id='SONOS_DISMISS_ALARM')`
    - queue cleared
  - Sonos mirror-only writer proofs:
    - `script.evening_alarm_check_notification`
    - `script.apple_tv_auto_off_notification`
- cleared the temporary queue/script proof artifacts after validation
- passed final static validation:
  - `npm run tinbox:check`

## What Changed This Session

- completed `TI2` and closed it on live evidence:
  - built `custom:tunet-inbox-card`
  - added rehab dashboard inbox fixtures
  - added standalone `tunet-inbox-yaml` dashboard
  - passed bespoke tests, full Tunet test suite, and v3 build
  - deployed the Tunet bundle live
  - proved live inbox rendering, respond-path submission, dismiss behavior, and empty-state recovery
- confirmed the standalone YAML dashboard is registered live and retrievable through HA
- recorded the operational activation rule:
  - first activation of a brand-new YAML dashboard registration required full HA restart
  - later content/resource updates can ride normal resource/deploy flows
- posted three dashboard-only demo items for manual validation:
  - TV Mode Prompt
  - TV Bridge Expiring
  - Apple TV Idle
- normalized the inbox card icon aliasing so unsupported/newer MDI names degrade to stable built-in symbols instead of disappearing

## Next Highest-Value Work

1. start `TI3`
2. cut selected OAL flows from compare mode to inbox-authoritative handling
3. preserve rollback safety while replacing direct mobile-only authority with governed inbox authority
4. keep Sonos authoritative cutover deferred until `TI3` closes

## Deployment Notes

- this worktree does not currently contain a checked-in `.env`
- deploy scripts must therefore support:
  - local `.env` in the current worktree when present
  - fallback to the primary repo root `.env`
- backend deploy must treat Python changes as `HA RESTART`
- latest live proof used:
  - remote host `10.0.0.21`
  - config backup under `Backups/tunet_inbox/`
  - successful smoke target `http://10.0.0.21:8123`
  - imported config-entry proof:
    - count `1`
    - source `import`
    - title `Tunet Inbox`
  - post-hardening proof:
    - `npm run tinbox:verify`
    - deploy completed
    - `ha_check_config() -> valid`
    - `ha_restart(confirm=true)`
    - post-restart `npm run tinbox:smoke`
  - TI1D live proof:
    - `npm run tinbox:smoke`
    - `npm run tinbox:probe:api`
    - live OAL pilot post via `automation.trigger`
    - live queue proof via `tunet_inbox.list_items`
    - live action proof via `tunet_inbox.respond(key=..., action_id=...)`
    - live clear proof via `tunet_inbox.list_items -> total 0`

## Risks / Watchpoints

- the next tranche must not reopen backend contract work unless compare-mode translation proves a real backend blocker
- compare-mode translation is complete; preserve the per-flow `action-ready` vs `mirror-only` classification when UI work starts
- do not let the Tunet card set the backend contract by accident
- keep receipts and clears explicit; do not overload the queue with informational notifications
- do not silently change action identifiers once package migrations start
- do not reopen package compare-mode logic during `TI2` unless UI work exposes a real backend contract defect
