# Tunet Inbox Fix Ledger

Working branch: `tunet/inbox-integration`  
Last updated: 2026-04-06

## Session Delta (2026-04-06, TI0 — Governance Scaffold)

Change marker: establish a local governed workstream before implementation widens into backend services, UI, or package migrations

- `CHOSEN INTERPRETATION`
  - user required the inbox work to be tranchable and governed similarly to the Tunet dashboard program
  - chosen implementation:
    - give `tunet_inbox` its own scoped `AGENTS.md`
    - create a local `plan.md`, `handoff.md`, and `FIX_LEDGER.md`
    - create explicit contract and deploy/test docs under `custom_components/tunet_inbox/Docs/`
    - make deploy/check/smoke capability part of tranche zero rather than an afterthought
- `RESULT`
  - the backend now has a local execution authority
  - later service/event/item contract changes will have a dedicated place to be recorded
  - package migrations and Tunet UI work can now reference a stable backend ledger instead of broad chat context

## Session Delta (2026-04-06, TI0 — Tranche Hardening)

Change marker: convert `TI0` from a broad active intention into a fully specified execution tranche and lock the planning-mode policy

- `CHOSEN INTERPRETATION`
  - the top-level program plan is necessary but not sufficient for safe execution
  - chosen implementation:
    - create a full tranche doc for `TI0`
    - make tranche docs mandatory before execution
    - document when explicit planning mode is required versus when default execution should continue
- `RESULT`
  - `TI0` can now be reviewed and executed against exact file boundaries, validation, stop conditions, and rollback
  - future tranches have a clear governance pattern to follow instead of relying on implicit chat agreement

## Session Delta (2026-04-06, Program Ledger Alignment)

Change marker: add a program-level ledger equivalent to Tunet's `visual_defect_ledger.md`

- `CHOSEN INTERPRETATION`
  - this project needs a normalized status surface above the tranche docs, not just a plan and handoff
  - chosen implementation:
    - create `custom_components/tunet_inbox/Docs/execution_ledger.md`
    - treat it as the cross-tranche normalized backlog and status authority for the inbox project
    - add it to the local governance review pack and precedence chain
- `RESULT`
  - `tunet_inbox` now has:
    - a program plan
    - a program ledger
    - tranche specs
    - session continuity docs
  - issue tracking can now stay normalized across backend, UI, OAL, Sonos, and rollout work

## Session Delta (2026-04-06, Planning Layer Deepening)

Change marker: harden the normalized planning layer from minimal governance into production-grade execution planning

- `CHOSEN INTERPRETATION`
  - the user wanted planning to start from the missing middle layer, not from more backend code
  - chosen implementation:
    - expand `execution_ledger.md` into the normalized issue authority
    - deepen `plan.md` with tranche dependencies, entry/exit gates, and program control rules
    - author full tranche specs for `TI1`, `TI2`, and `TI3`
    - replace the stale enhancement tracker with an inbox-specific enhancement matrix
- `RESULT`
  - the project now has a complete planning stack:
    - policy
    - program plan
    - normalized ledger
    - tranche execution docs
    - continuity docs
    - enhancement decision matrix
  - the next implementation step can proceed without reopening planning ambiguity

## Open Items

- TI0 still needs backend scaffold files
- TI0 still needs deploy/check/smoke scripts and npm wiring
- TI0 still needs package.json and `Configuration/configuration.yaml` wiring plus first validation pass
- TI1 must enforce and prove the final runtime storage and service behavior in HA
