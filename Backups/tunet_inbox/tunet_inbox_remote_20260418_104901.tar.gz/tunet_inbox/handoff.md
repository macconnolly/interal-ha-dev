# Tunet Inbox Handoff

Last updated: 2026-04-18 (America/Denver)  
Working branch: `tunet/inbox-integration`

## Current State

- `tunet_inbox` backend is live and governed from `custom_components/tunet_inbox/`.
- Closed tranches:
  - `TI0`
  - `TI1`
  - `TI1A`
  - `TI1B`
  - `TI1C`
  - `TI1D`
  - `TI1E`
  - `TI2`
  - `TI2A`
  - `TI2B`
- Active tranche:
  - `custom_components/tunet_inbox/Docs/tranches/TI2C_inbox_tap_contract_canonicalization.md`
  - status: `ACTIVE`
  - scope is frozen for backend-only contract canonicalization before any package cutover resumes
- Latest closed tranche:
  - `custom_components/tunet_inbox/Docs/tranches/TI2B_mobile_url_public_service_schema_parity.md`
  - status: `CLOSED`
- No `Dashboard/Tunet/**` tranche is active.
- `TI3` is no longer `READY TO START`; it is intentionally resequenced behind `TI2C`.
- `TI2B` remains closed as a narrow parity patch.
- The current live `mobile.url` path is aligned across service schema, model validation, queue persistence, and runtime mobile payload emission, but it is no longer treated as the durable contract decision.

## Latest Proven State

- Backend:
  - `npm run tinbox:check`
  - `npm run tinbox:test`
  - `npm run tinbox:smoke`
  - `npm run tinbox:probe:api`
  - imported config entry is loaded with `options = {}`
  - notify routing is live through `notify.tunet_inbox_all_devices`
- Compare-mode package coverage:
  - OAL mirrored:
    - override reminder
    - override expiring
    - TV mode activated
    - TV mode prompt
    - bridge expiring
    - TV presence prompt
    - unified timer expiring
  - Sonos mirrored:
    - alarm playing
    - evening alarm check
    - Apple TV auto-off
- Inbox UI:
  - `custom:tunet-inbox-card` is live
  - rehab fixtures exist
  - standalone dashboard `tunet-inbox-yaml` is registered and reachable
- Mobile continuity:
  - direct iOS notifications still send
  - touched notifications body-tap to `/tunet-inbox-yaml/inbox`
  - touched confirmation receipts were removed
  - OAL TV prompt has a 5-minute debounce
  - `sensor.sonos_alarm_playing` no longer restores into a broken/unavailable state
- TI2B proof:
  - local validation passed:
    - `python3 -m py_compile custom_components/tunet_inbox/*.py`
    - `python3 -m py_compile tests/components/tunet_inbox/*.py`
    - `npm run tinbox:check`
    - `npm run tinbox:test` -> `21 passed`
  - live validation passed:
    - integration-only deploy from the worktree
    - `ha_check_config() -> valid`
    - HA restart
    - `npm run tinbox:smoke`
    - `tunet_inbox.post` with `mobile.url` returned `accepted: true`
    - `tunet_inbox.list_items` showed stored `mobile.url: "/tunet-inbox-yaml/inbox"`
    - the proof item was dismissed and the queue returned to `total: 0`
  - planning-control audit reran:
    - `npm run tinbox:check`
    - `npm run tinbox:test` -> `21 passed`
    - `npm run tinbox:smoke`
    - live `tunet_inbox.post(send_mobile=false)` with canonical `mobile.url`
    - live `tunet_inbox.list_items` showed the persisted canonical `mobile.url`
    - the audit item was dismissed successfully

## Current Contract Assumptions

- dashboard ingress must go through `tunet_inbox.respond`
- canonical business event is `tunet_inbox_action`
- queue refresh event is `tunet_inbox_updated`
- raw mobile action format is `TINBOX|<item_id>|<action_id>`
- queue items are governed objects, not arbitrary JSON blobs
- action payloads are identifiers and render metadata only
- malformed persisted payloads must be quarantined and surfaced, not silently skipped
- the governed inbox tap target is `/tunet-inbox-yaml/inbox`
- the current raw `mobile.url` field is a live compatibility surface, not the intended long-term public contract
- default notify target may be either:
  - a helper entity containing a mobile-app device id
  - a direct `notify.*` service such as a notify group
- blank notify routing is invalid and does not mean “all devices”

## Known Gaps / Stubs

- No OAL flow is inbox-authoritative in production yet.
- `TI2C` is still open:
  - inbox tap ownership is not yet canonicalized into the backend
  - caller-supplied raw route strings still exist as a compatibility surface
- Compare-mode duplication still exists by design for all non-cutover flows.
- Sonos authoritative cutover has not started.
- The first Sonos authoritative pilot is now frozen to `sonos_alarm_playing` only.
- `sonos_evening_alarm_check` and `sonos_apple_tv_auto_off` remain `shadow + mirror-only` and are explicitly out of the first TI4 pilot.
- Bridge-expiring, presence-loss, TV-mode-activated, and unified-timer OAL flows remain compare-mode only and are explicitly out of TI3 scope.
- The delivery fan-out path still depends on the Home Assistant notify group `notify.tunet_inbox_all_devices`; end-device receipt is outside the integration runtime and should be verified from the mobile side when delivery questions arise.
- One stale live ops probe item remains in HA:
  - key: `ti2b_mobile_delivery_probe_20260418_002343`
  - clear it before treating the next live proof run as a clean queue-state demonstration

## TI3 Frozen Cutover Set

- `oal_override_reminder`
- `oal_override_expiring:<zone>`
- `oal_tv_mode_prompt:living_room`

Everything else in OAL stays compare-mode for now.

## Next Highest-Value Work

1. implement `TI2C` inside the frozen backend-only file boundary
2. canonicalize inbox tap behavior so mobile deliveries open the governed inbox surface by backend-owned default rather than caller-owned raw route strings
3. only after `TI2C` closes, resume the frozen `TI3` OAL authoritative cutover set:
   - `oal_override_reminder`
   - `oal_override_expiring:<zone>`
   - `oal_tv_mode_prompt:living_room`

## Deployment Notes

- this worktree does not currently contain a checked-in `.env`
- deploy scripts must therefore support:
  - local `.env` in the current worktree when present
  - fallback to the primary repo root `.env`
- backend deploy must treat Python changes as `HA RESTART`
- package-only TI3 work should prefer package deploy/reload rather than unrelated backend restarts
- latest live proof used:
  - remote host `10.0.0.21`
  - config backup under `Backups/tunet_inbox/`
  - successful smoke target `http://10.0.0.21:8123`

## Risks / Watchpoints

- TI3 was previously blocked by a real backend contract gap; do not re-open that closed issue unless new contradictory evidence appears
- treat `TI2B` as a parity patch, not the final inbox-tap architecture
- do not widen `TI2C` into OAL, Sonos, or `Dashboard/Tunet/**`
- preserve the per-flow `action-ready` vs `mirror-only` classification during package cutover work
- do not broaden `TI4` beyond `sonos_alarm_playing` unless Sonos mirror-only flows are explicitly reclassified in governance first
- keep receipts and clears explicit; do not overload the queue with informational notifications
- do not silently change action identifiers once package migrations start
- do not widen TI3 into bridge, presence-loss, or unified-timer migration unless a documented stop condition forces a new control point
