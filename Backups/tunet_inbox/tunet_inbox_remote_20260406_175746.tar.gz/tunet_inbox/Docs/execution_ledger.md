Built from the current governed state of the `tunet_inbox` worktree using the active plan, tranche docs, contracts, deploy rules, and implementation files as evidence. This is the normalized cross-tranche status authority for the inbox project.

This file separates:
1. normalized project status and ownership at the top
2. detailed repo-grounded implementation evidence in the appendix

When the normalized section and the appendix differ, the normalized section wins.

## Normalized Status Model

- `Open contract gap`
  - the intended behavior is known, but a contract, authority, or governance rule is incomplete
- `Open implementation blocker`
  - the contract is acceptable, but a missing implementation capability blocks safe progress
- `In-flight tranche work`
  - active work owned by the current tranche with a frozen file boundary
- `Validation debt`
  - implementation exists, but required static, runtime, or HA/live evidence is missing
- `Deferred by policy`
  - the need is real, but the current program order intentionally keeps it out of scope
- `Closed / superseded`
  - earlier framing has been replaced by the current normalized model

## Priority Model

- `P0`
  - cannot safely advance the current tranche or promote the next tranche
- `P1`
  - can advance the current tranche, but blocks the next tranche
- `P2`
  - important follow-on work within the declared program order
- `P3`
  - low-priority refinement or deferred hardening

## Evidence Model

- `Docs evidence`
  - plan, ledger, tranche docs, contracts, deploy docs, handoff, and fix ledger agree
- `Static evidence`
  - syntax, parse, and script validation passes
- `Runtime evidence`
  - local command-path behavior is proven without requiring HA deployment
- `HA/live evidence`
  - deploy, restart/reload, and smoke validation have passed against the actual HA instance

No issue is considered fully closed if the required evidence layer for its tranche has not been met.

## Tranche State Model

- `Not ready`
  - dependencies or gates are still open
- `Ready to start`
  - entry gates are met and a tranche spec exists
- `Active`
  - tranche is the current execution authority
- `Ready to close`
  - acceptance criteria are implemented and validation remains
- `Closed`
  - exit criteria and required evidence are complete
- `Blocked`
  - a stop condition has been reached and no safe continuation exists inside the tranche boundary

## Current Program Snapshot

| Tranche | Scope | Current state | Why not promoted further |
|---------|-------|---------------|---------------------------|
| `TI0` | governance scaffold, backend skeleton, deploy/check/smoke path | `Active` | package wiring, HA bootstrap wiring, and first validation pass are still open |
| `TI1` | service pipeline and storage enforcement | `Not ready` | blocked on `TI0` exit gates |
| `TI2` | Tunet inbox card and dashboard surfaces | `Not ready` | blocked on `TI1` contract proof |
| `TI3` | OAL pilot migration | `Not ready` | blocked on `TI1` service/event proof and `TI2` dashboard surface |
| `TI4` | Sonos pilot migration | `Deferred by policy` | blocked on `TI3` proving the first domain migration |
| `TI5` | TV/timer/confirmable expansion | `Deferred by policy` | blocked on pilot migrations |
| `TI6` | diagnostics, repairs, corruption handling | `Deferred by policy` | intentionally postponed until functional migration path is proven |

## Canonical Dependency Matrix

| From | To | Dependency type | Description |
|------|----|-----------------|-------------|
| `TI0` | `TI1` | hard | `TI1` cannot start until operator commands, YAML bootstrap, and base validation exist |
| `TI1` | `TI2` | hard | the card cannot be built against an unproven backend contract |
| `TI1` | `TI3` | hard | OAL migration cannot use the inbox until the service/event path is proven |
| `TI2` | `TI3` | hard | OAL pilot is not considered complete without the dashboard recovery surface |
| `TI3` | `TI4` | policy | Sonos migration follows the first successful domain pilot |
| `TI3` | `TI5` | hard | expansion waits on the OAL pilot proof |
| `TI4` | `TI5` | hard | expansion waits on both pilot migrations |
| `TI5` | `TI6` | policy | hardening follows the main functional rollout |

## Canonical Decision Matrix

| Area | Role | Normalized position | Owning tranche | Next promotion gate |
|------|------|---------------------|----------------|---------------------|
| Governance pack | execution authority | structurally present and synchronized enough for current program control | `TI0` | keep synced as implementation advances |
| Program ledger | normalized backlog authority | present and materially normalized for current program control | `TI0` | keep synced as tranche state changes |
| Contracts | service/event/item authority | acceptable for planning and scaffold work; not yet proven in HA | `TI0 / TI1` | service proof and state-machine validation |
| Backend runtime skeleton | integration control plane | scaffold exists, but operator path and bootstrap wiring are incomplete | `TI0` | package.json wiring, config wiring, static validation |
| Deploy / check / smoke path | operator safety path | scripts exist; repo integration and first proof are still open | `TI0` | commands wired and executed |
| Tunet inbox card | renderer/requester | deferred until backend proof exists | `TI2` | `TI1` closes |
| OAL pilot migration | first domain migration | deferred until backend proof and dashboard surface exist | `TI3` | `TI1` and `TI2` close |
| Sonos pilot migration | second domain migration | intentionally sequenced after OAL pilot | `TI4` | `TI3` closes |
| Expansion migration | remaining flows | intentionally deferred | `TI5` | `TI3` and `TI4` close |
| Diagnostics / repairs | supportability hardening | known future need, intentionally deferred | `TI6` | `TI5` closes |
| Enhancement tracker | external/internal planning matrix | inbox-specific matrix now exists and replaces the old dashboard-centric tracker | `TI0` | keep synced if the question set changes again |

## Canonical Open Issue Matrix

| ID | Title | Class | Priority | Status | Owner | Depends on | Required evidence to close | Next action |
|----|-------|-------|----------|--------|-------|------------|----------------------------|-------------|
| `TINBOX-GOV-1` | Artifact stack roles were implicit | `Open contract gap` | `P0` | `Closed / superseded` | `TI0` | none | docs evidence | closed by local governance pack + artifact stack rule |
| `TINBOX-GOV-2` | Program ledger did not exist | `Open contract gap` | `P0` | `Closed / superseded` | `TI0` | none | docs evidence | closed by `Docs/execution_ledger.md` |
| `TINBOX-GOV-3` | TI1-TI3 lacked tranche specs | `Open contract gap` | `P0` | `Closed / superseded` | `TI0` | none | docs evidence | closed by authoring `TI1`, `TI2`, and `TI3` tranche docs |
| `TINBOX-GOV-4` | Planning-mode policy was not explicit | `Open contract gap` | `P1` | `Closed / superseded` | `TI0` | none | docs evidence | closed in `AGENTS.md` + tranche template |
| `TINBOX-BE-1` | Repo does not expose operator commands for inbox workflows | `Open implementation blocker` | `P0` | `Open implementation blocker` | `TI0` | none | static + runtime evidence | wire `tinbox:*` scripts into `package.json` |
| `TINBOX-BE-2` | HA YAML bootstrap for tunet_inbox is missing | `Open implementation blocker` | `P0` | `Open implementation blocker` | `TI0` | none | docs + static evidence | add `tunet_inbox:` block and logger entries to `Configuration/configuration.yaml` |
| `TINBOX-BE-3` | Backend scaffold has not been statically validated end-to-end | `Validation debt` | `P0` | `Validation debt` | `TI0` | `TINBOX-BE-1`, `TINBOX-BE-2` | static evidence | run `py_compile`, script checks, and YAML parse after wiring |
| `TINBOX-BE-4` | Deploy/smoke path exists but has no recorded proof | `Validation debt` | `P1` | `Validation debt` | `TI0` | `TINBOX-BE-1`, `TINBOX-BE-2` | runtime + HA/live evidence | execute deploy/smoke once TI0 code path is stable |
| `TINBOX-TI1-1` | Service registration and response contract are unproven in HA | `Open implementation blocker` | `P0` | `Deferred by policy` | `TI1` | `TI0` closed | HA/live evidence | implement and verify `TI1` |
| `TINBOX-TI1-2` | State machine, dedupe, and timeout recovery are not yet proven | `Validation debt` | `P1` | `Deferred by policy` | `TI1` | `TINBOX-TI1-1` | runtime + HA/live evidence | implement and verify `TI1` |
| `TINBOX-UI-1` | Tunet inbox card does not exist | `Open implementation blocker` | `P1` | `Deferred by policy` | `TI2` | `TI1` closed | static + runtime + Tunet validation | implement `TI2` |
| `TINBOX-UI-2` | Dedicated inbox dashboard surfaces do not exist | `Open implementation blocker` | `P2` | `Deferred by policy` | `TI2` | `TINBOX-UI-1` | static + HA/live evidence | implement rehab and standalone dashboard |
| `TINBOX-OAL-1` | OAL actionable flows still use direct mobile paths | `Open implementation blocker` | `P1` | `Deferred by policy` | `TI3` | `TI1`, `TI2` | HA/live evidence | migrate override reminder + override expiring |
| `TINBOX-OAL-2` | OAL natural resolver ownership is not yet mapped end-to-end | `Open contract gap` | `P2` | `Deferred by policy` | `TI3` | `TINBOX-OAL-1` | docs + HA/live evidence | implement explicit resolve ownership in TI3 |
| `TINBOX-SONOS-1` | Sonos alarm flows still use direct mobile paths | `Open implementation blocker` | `P2` | `Deferred by policy` | `TI4` | `TI3` | HA/live evidence | migrate alarm playing after OAL pilot closes |
| `TINBOX-EXP-1` | TV/timer/confirmable flows are unmigrated | `Deferred by policy` | `P3` | `Deferred by policy` | `TI5` | `TI3`, `TI4` | HA/live evidence | start after pilot migrations |
| `TINBOX-HARDEN-1` | Diagnostics, repairs, and corruption handling are absent | `Deferred by policy` | `P3` | `Deferred by policy` | `TI6` | `TI5` | docs + static + HA/live evidence | implement hardening tranche |
| `TINBOX-TRACK-1` | Enhancement tracker did not match the new inbox question set | `Open contract gap` | `P1` | `Closed / superseded` | `TI0` | none | docs evidence | closed by `HA-References/tunet_inbox_enhancement_matrix.md` and deprecating the old dashboard tracker |

## Tranche-Owned Open Backlog

### `TI0`

- close `TINBOX-BE-1`
- close `TINBOX-BE-2`
- reduce `TINBOX-BE-3` from validation debt to closed

### `TI1`

- close `TINBOX-TI1-1`
- close `TINBOX-TI1-2`

### `TI2`

- close `TINBOX-UI-1`
- close `TINBOX-UI-2`

### `TI3`

- close `TINBOX-OAL-1`
- close `TINBOX-OAL-2`

### `TI4`

- close `TINBOX-SONOS-1`

### `TI5`

- close `TINBOX-EXP-1`

### `TI6`

- close `TINBOX-HARDEN-1`

## Current Highest-Confidence Risks

- `P0`: backend drift between docs, scripts, package wiring, and HA bootstrap before the first successful check/smoke run
- `P0`: widening into Tunet or package files before `TI0` and `TI1` close
- `P1`: building a Tunet inbox card before the backend response contract is proven
- `P1`: migrating OAL without the dashboard surface, which would violate the recovery requirement

## Control Notes

- The plan is now specific enough at the program level, but execution still must be governed by a fully filled tranche doc each time.
- Plan mode is not required for every narrow edit. It is required at control points:
  - new tranche start
  - public contract change
  - allowed-file widening
  - deploy/restart/rollback ambiguity
  - ownership ambiguity
- `TI0` remains the only active tranche. No other tranche is ready to start.

---

## Detailed Implementation Appendix (2026-04-06)

### Current repo-grounded evidence

- governance stack exists:
  - `custom_components/tunet_inbox/AGENTS.md`
  - `custom_components/tunet_inbox/plan.md`
  - `custom_components/tunet_inbox/handoff.md`
  - `custom_components/tunet_inbox/FIX_LEDGER.md`
  - `custom_components/tunet_inbox/Docs/contracts.md`
  - `custom_components/tunet_inbox/Docs/deploy_and_test.md`
  - `custom_components/tunet_inbox/Docs/TRANCHE_TEMPLATE.md`
  - `custom_components/tunet_inbox/Docs/tranches/TI0_governance_scaffold_core_backend_skeleton.md`
- backend scaffold exists:
  - `__init__.py`
  - `const.py`
  - `models.py`
  - `storage.py`
  - `events.py`
  - `mobile.py`
  - `manager.py`
  - `services.py`
  - `manifest.json`
  - `services.yaml`
- operator scripts exist:
  - `custom_components/tunet_inbox/scripts/check_tunet_inbox.sh`
  - `custom_components/tunet_inbox/scripts/deploy_tunet_inbox.sh`
  - `custom_components/tunet_inbox/scripts/tunet_inbox_smoke.mjs`

### Current unresolved evidence gaps

- `package.json`
  - no `tinbox:*` scripts yet
- `Configuration/configuration.yaml`
  - no `tunet_inbox:` bootstrap block yet
- no recorded successful validation for:
  - `python3 -m py_compile custom_components/tunet_inbox/*.py`
  - `bash custom_components/tunet_inbox/scripts/check_tunet_inbox.sh`
  - `node --check custom_components/tunet_inbox/scripts/tunet_inbox_smoke.mjs`
- tranche docs now exist for:
  - `TI0`
  - `TI1`
  - `TI2`
  - `TI3`

### Program guidance

- do not start card work under `Dashboard/Tunet/**` until `TINBOX-BE-1`, `TINBOX-BE-2`, and `TINBOX-BE-3` are closed and `TI1` is ready
- do not start OAL or Sonos migration until the backend service/event path is proven in HA
- use the ledger as the normalized issue authority, the plan as the program order authority, and tranche docs as execution authority
