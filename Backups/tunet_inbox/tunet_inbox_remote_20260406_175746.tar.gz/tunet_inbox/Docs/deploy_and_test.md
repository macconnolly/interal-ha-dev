# Tunet Inbox Deploy And Test

## Architecture

```
Source:    custom_components/tunet_inbox/*.py
Docs:      custom_components/tunet_inbox/{plan.md,handoff.md,FIX_LEDGER.md}
Deploy:    /config/custom_components/tunet_inbox/
Smoke:     HA REST service discovery + optional service invocation
```

`tunet_inbox` is a backend integration, so there is no frontend build step.
Instead, the governed workflow is:

1. static check
2. deploy integration files
3. restart HA if Python changed
4. smoke-check service registration
5. only then widen to package or UI changes

## npm Scripts

| Script | Command | Purpose |
|--------|---------|---------|
| `tinbox:check` | `bash custom_components/tunet_inbox/scripts/check_tunet_inbox.sh` | Static validation for backend files and tied YAML |
| `tinbox:deploy:integration` | `bash custom_components/tunet_inbox/scripts/deploy_tunet_inbox.sh` | Backup + deploy the integration files to HA |
| `tinbox:smoke` | `node custom_components/tunet_inbox/scripts/tunet_inbox_smoke.mjs` | Verify `tunet_inbox` services exist in HA |

## Environment Resolution

The worktree may not contain a local `.env`.

Deploy and smoke scripts must therefore resolve environment in this order:

1. `<current worktree>/.env`
2. `/home/mac/HA/implementation_10/.env`

Required values:
- `HA_SSH_HOST`
- `HA_SSH_USER`
- `HA_SSH_PASSWORD`
- `HA_LONG_LIVED_ACCESS_TOKEN` or `HA_TOKEN`

Optional values:
- `HA_URL`

If `HA_URL` is absent, derive:
- `http://${HA_SSH_HOST}:8123`

## Static Validation

`tinbox:check` must:

- run `python3 -m py_compile` over `custom_components/tunet_inbox/*.py`
- parse `Configuration/configuration.yaml` if touched
- verify the governance docs exist
- fail fast with a non-zero exit code

## Deploy Workflow

### Integration deploy

```bash
npm run tinbox:deploy:integration
```

This must:

1. resolve `.env`
2. back up the remote `/config/custom_components/tunet_inbox/` into a local timestamped backup folder
3. create the remote directory if missing
4. copy the integration files to `/config/custom_components/tunet_inbox/`
5. print the required restart instruction

### Restart policy

If Python integration files changed:
- restart Home Assistant

If only docs changed:
- no HA action required

If only package YAML changes later:
- use the package deploy/reload flow for that tranche

## Smoke Workflow

```bash
npm run tinbox:smoke
```

The smoke script must:

1. resolve `.env`
2. call `GET /api/services`
3. verify the `tunet_inbox` domain exists
4. verify these services exist:
   - `post`
   - `respond`
   - `resolve`
   - `fail`
   - `dismiss`
   - `list_items`

If any are missing, the smoke script must fail with a non-zero exit code.

## Rollback

Small rollback path:

1. copy the latest local backup of `/config/custom_components/tunet_inbox/` back to the HA host
2. restart HA
3. re-run `npm run tinbox:smoke`

## Acceptance Expectations

The backend is not “deployed” just because files copied successfully.
Minimum deploy acceptance:

- static check passed
- files copied
- HA restarted when required
- smoke check passed

