# TI3 — OAL Pilot Migration

## TRANCHE_ID

- `TI3`

## TITLE

- `Migrate OAL override reminder and override-expiring flows onto the governed inbox path`

## STATUS

- `PLANNED`

## PLAN_MODE_DECISION

- `PLAN MODE REQUIRED`
- Rationale:
  - this tranche crosses into live package automation behavior
  - it is the first production domain migration
  - it depends on both the backend and the dashboard surface being proven

## SOURCE_ITEMS

- `custom_components/tunet_inbox/plan.md`
  - `TI3 — OAL Pilot Migration`
- `custom_components/tunet_inbox/Docs/execution_ledger.md`
  - `TINBOX-OAL-1`
  - `TINBOX-OAL-2`
- `packages/oal_lighting_control_package.yaml`
  - current OAL notification flows around override reminder and override-expiring logic

## GOAL

- Replace the direct mobile-action pattern for the OAL override reminder and override-expiring flows with the `tunet_inbox` post/respond/resolve model while preserving existing user-facing action outcomes and adding dashboard recoverability.

## WHY_NOW

- This is the first domain slice that proves the inbox architecture solves the original problem.
- The selected OAL flows are bounded, frequent enough to validate the model, and safer than starting with the broader TV/timer logic.
- A successful pilot gives Sonos migration a concrete reference.

## USER_VISIBLE_OUTCOME

- If the OAL override reminder or override-expiring notification is missed or dismissed on the phone, the action context remains available in the dashboard inbox.
- The same semantic actions work from phone and dashboard.
- Natural resolution clears both the queue item and the mobile prompt.

## FILES_ALLOWED

- `packages/oal_lighting_control_package.yaml`
- `custom_components/tunet_inbox/plan.md`
- `custom_components/tunet_inbox/FIX_LEDGER.md`
- `custom_components/tunet_inbox/handoff.md`
- `custom_components/tunet_inbox/Docs/contracts.md`
- `custom_components/tunet_inbox/Docs/execution_ledger.md`
- `custom_components/tunet_inbox/Docs/tranches/TI3_oal_pilot_migration.md`
- `HA-References/tunet_inbox_enhancement_matrix.md`

## FILES_FORBIDDEN_UNLESS_BLOCKED

- `Dashboard/Tunet/**`
- `packages/sonos_package.yaml`
- `custom_components/tunet_inbox/__init__.py`
- `custom_components/tunet_inbox/manager.py`
- `custom_components/tunet_inbox/services.py`
- `Configuration/configuration.yaml`

## CURRENT_STATE

- `TI1` and `TI2` are assumed complete.
- OAL override reminder and override-expiring flows still use a direct mobile-notification pattern.
- If the mobile notification is dismissed or missed, the action context is lost.

## INTENDED_STATE

- OAL override reminder posts to `tunet_inbox`.
- OAL override-expiring posts to `tunet_inbox`.
- OAL action handling listens to `tunet_inbox_action` for the migrated actions.
- natural resolver paths call `tunet_inbox.resolve`.
- the same semantic actions work from:
  - iPhone actionable notification
  - Tunet inbox card

## EXACT_CHANGE_IN_ENGLISH

- Replace direct `notify.mobile_app_*` sends for the selected OAL flows with `tunet_inbox.post`.
- Preserve the existing semantic action IDs for the selected flows where possible.
- Replace raw `mobile_app_notification_action` handling for those flows with `tunet_inbox_action`.
- Add explicit resolve paths for:
  - user action success
  - natural state resolution
  - expiry or supersession
- Keep all domain decisions and side effects inside OAL automations/scripts.
- Do not migrate TV mode, bridge, presence, or unified timer in this tranche.

## ARCHITECTURAL_INTENTION

- This tranche proves the governed inbox architecture on a real production domain without widening into the whole OAL package.
- It validates:
  - send path
  - dashboard recovery path
  - canonical response event path
  - natural resolver ownership
- It also creates the concrete migration pattern that Sonos will follow next.

## ACCEPTANCE_CRITERIA

- override reminder uses `tunet_inbox.post`
- override-expiring uses `tunet_inbox.post`
- migrated OAL action handlers listen to `tunet_inbox_action`, not raw mobile events
- natural resolver automations call `tunet_inbox.resolve`
- the original domain outcomes still occur:
  - reset to adaptive works
  - keep manual works
  - extend override works
  - let expire works
- if the phone notification is dismissed on iOS:
  - the inbox item remains available
  - dashboard action still works
- acting from the dashboard clears the phone notification by tag
- acting from the phone clears the dashboard item
- if the underlying OAL condition resolves before user action:
  - the inbox item auto-clears
  - the phone prompt is cleared by tag if still present

## VALIDATION

### Static validation

- YAML parse-check for `packages/oal_lighting_control_package.yaml`
- verify migrated blocks still compile as valid HA YAML

### Runtime validation

- inspect the migrated automation/script branches for:
  - correct item keys
  - correct action IDs
  - correct resolve ownership
- review that no raw mobile event handling remains for the migrated actions

### HA/live validation

- deploy the changed OAL package
- reload automations or restart HA as required
- trigger override reminder
- trigger override-expiring path
- validate:
  - phone action
  - dashboard action
  - iOS swipe-dismiss retains inbox item
  - natural resolution clears the queue
  - duplicate/stale response is rejected safely

## DEPLOY_IMPACT

- `HA PACKAGE RELOAD`
- `HA RESTART` only if backend integration code changes concurrently as a blocker exception

## ROLLBACK

- restore prior `packages/oal_lighting_control_package.yaml`
- reload automations or restart HA
- verify old mobile-only flow is active again

## DEPENDENCIES

- `TI1` is closed
- `TI2` is closed
- inbox card and standalone dashboard are available for validation
- OAL entity/state assumptions for the pilot flows are verified before editing

## UNKNOWNS

- whether existing OAL helper timers or soonest-override logic require small keying adjustments
- whether the current OAL automation layout needs narrow helper automations for clean resolver ownership

## STOP_CONDITIONS

- stop if migration requires backend contract changes
- stop if migration needs to widen into TV/timer flows
- stop if resolver ownership cannot be isolated for the two selected OAL flows
- stop if package reload behavior is not sufficient and broader restart sequencing becomes unclear

## OUT_OF_SCOPE

- OAL TV mode flows
- OAL bridge expiring flows
- OAL presence-loss flows
- OAL unified timer migration
- Sonos migration
- frontend card changes

## REVIEW_FOCUS

- migration narrowness
- action parity between phone and dashboard
- resolve ownership clarity
- preservation of OAL business logic boundaries
- stale-action safety

