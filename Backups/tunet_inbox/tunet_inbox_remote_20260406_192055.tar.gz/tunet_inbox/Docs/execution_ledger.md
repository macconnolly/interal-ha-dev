Built from the current governed state of the `tunet_inbox` worktree using the active plan, tranche docs, contracts, deploy rules, and implementation files as evidence. This is the normalized cross-tranche status authority for the inbox project.

This file separates:
1. normalized project status and ownership at the top
2. detailed repo-grounded implementation evidence in the appendix

When the normalized section and the appendix differ, the normalized section wins.

## Normalized Status Model

- `Open contract gap`
  - the intended behavior is known, but a contract, authority, or governance rule is incomplete
- `Open implementation blocker`
  - the contract is acceptable, but a missing implementation capability blocks safe progress
- `In-flight tranche work`
  - active work owned by the current tranche with a frozen file boundary
- `Validation debt`
  - implementation exists, but required static, runtime, or HA/live evidence is missing
- `Deferred by policy`
  - the need is real, but the current program order intentionally keeps it out of scope
- `Closed / superseded`
  - earlier framing has been replaced by the current normalized model

## Priority Model

- `P0`
  - cannot safely advance the current tranche or promote the next tranche
- `P1`
  - can advance the current tranche, but blocks the next tranche
- `P2`
  - important follow-on work within the declared program order
- `P3`
  - low-priority refinement or deferred hardening

## Evidence Model

- `Docs evidence`
  - plan, ledger, tranche docs, contracts, deploy docs, handoff, and fix ledger agree
- `Static evidence`
  - syntax, parse, and script validation passes
- `Runtime evidence`
  - local command-path behavior is proven without requiring HA deployment
- `HA/live evidence`
  - deploy, restart/reload, and smoke validation have passed against the actual HA instance

No issue is considered fully closed if the required evidence layer for its tranche has not been met.

## Tranche State Model

- `Not ready`
  - dependencies or gates are still open
- `Ready to start`
  - entry gates are met and a tranche spec exists
- `Active`
  - tranche is the current execution authority
- `Ready to close`
  - acceptance criteria are implemented and validation remains
- `Closed`
  - exit criteria and required evidence are complete
- `Blocked`
  - a stop condition has been reached and no safe continuation exists inside the tranche boundary

## Current Program Snapshot

| Tranche | Scope | Current state | Why not promoted further |
|---------|-------|---------------|---------------------------|
| `TI0` | governance scaffold, backend skeleton, deploy/check/smoke path | `Closed` | closed by package wiring, YAML bootstrap, and static validation evidence |
| `TI1` | service pipeline and storage enforcement | `Closed` | closed by live HA proof plus deterministic runtime proof for the literal `lock_conflict` branch |
| `TI1A` | local HA integration test harness | `Closed` | closed by pinned local test environment, governed operator scripts, and passing targeted backend pytest suite |
| `TI1B` | integration productization and supportability | `Closed` | closed by config-entry runtime, YAML import path, diagnostics, translations, manifest cleanup, and live imported-entry proof |
| `TI1C` | corruption quarantine, repairs, and release verification | `Active` | malformed persisted queue items are still skipped instead of quarantined and surfaced |
| `TI2` | Tunet inbox card and dashboard surfaces | `Not ready` | intentionally deferred until `TI1C` closes |
| `TI3` | OAL pilot migration | `Not ready` | blocked on `TI1C` backend hardening and `TI2` dashboard surface |
| `TI4` | Sonos pilot migration | `Deferred by policy` | blocked on `TI3` proving the first domain migration |
| `TI5` | TV/timer/confirmable expansion | `Deferred by policy` | blocked on pilot migrations |
| `TI6` | diagnostics, repairs, corruption handling | `Deferred by policy` | intentionally postponed until functional migration path is proven |

## Canonical Dependency Matrix

| From | To | Dependency type | Description |
|------|----|-----------------|-------------|
| `TI0` | `TI1` | hard | `TI1` cannot start until operator commands, YAML bootstrap, and base validation exist |
| `TI1` | `TI1A` | hard | the test harness must target a stable backend contract and live-proven runtime path |
| `TI1A` | `TI1B` | hard | productization work depends on the existing local regression harness |
| `TI1B` | `TI1C` | hard | the remaining production blocker is backend supportability, not UI work |
| `TI1C` | `TI2` | hard | the card should not advance before malformed-state handling and release verification are governed |
| `TI1C` | `TI3` | hard | OAL migration should not begin before quarantine/repairs behavior is settled |
| `TI2` | `TI3` | hard | OAL pilot is not considered complete without the dashboard recovery surface |
| `TI3` | `TI4` | policy | Sonos migration follows the first successful domain pilot |
| `TI3` | `TI5` | hard | expansion waits on the OAL pilot proof |
| `TI4` | `TI5` | hard | expansion waits on both pilot migrations |
| `TI5` | `TI6` | policy | hardening follows the main functional rollout |

## Canonical Decision Matrix

| Area | Role | Normalized position | Owning tranche | Next promotion gate |
|------|------|---------------------|----------------|---------------------|
| Governance pack | execution authority | structurally present and synchronized enough for current program control | `TI0` | keep synced as implementation advances |
| Program ledger | normalized backlog authority | present and materially normalized for current program control | `TI0` | keep synced as tranche state changes |
| Contracts | service/event/item authority | materially proven in HA and by deterministic runtime probe for the core service path | `TI1` | keep stable while test harness is added |
| Backend runtime skeleton | integration control plane | deployed and loading in HA with literal `lock_conflict` proof recorded | `TI1` | keep stable while test harness is added |
| Deploy / check / smoke path | operator safety path | first HA/live proof is recorded and remote bootstrap patching is now governed | `TI1` | keep the path stable for future tranches |
| Local HA integration test harness | regression safety path | present with pinned requirements, repo-local venv workflow, and governed operator commands | `TI1A` | keep stable while later backend hardening lands |
| Targeted backend tests | manager/service/event protection | present for manager state transitions, service responses, config flow behavior, diagnostics redaction, and canonical event emission | `TI1A` | expand for quarantine/repairs behavior |
| Integration productization | config entry, diagnostics, translation-backed supportability | complete and live-proven | `TI1B` | hold stable while TI1C lands |
| Corruption handling and release verification | quarantine, repairs, and governed local release gate | active backend hardening tranche | `TI1C` | close malformed-state and verification gaps |
| Tunet inbox card | renderer/requester | intentionally deferred until backend corruption handling and release verification complete | `TI2` | `TI1C` closes |
| OAL pilot migration | first domain migration | deferred until backend proof and dashboard surface exist | `TI3` | `TI1A` and `TI2` close |
| Sonos pilot migration | second domain migration | intentionally sequenced after OAL pilot | `TI4` | `TI3` closes |
| Expansion migration | remaining flows | intentionally deferred | `TI5` | `TI3` and `TI4` close |
| Diagnostics / repairs | supportability hardening | known future need, intentionally deferred | `TI6` | `TI5` closes |
| Enhancement tracker | external/internal planning matrix | inbox-specific matrix now exists and replaces the old dashboard-centric tracker | `TI0` | keep synced if the question set changes again |

## Canonical Open Issue Matrix

| ID | Title | Class | Priority | Status | Owner | Depends on | Required evidence to close | Next action |
|----|-------|-------|----------|--------|-------|------------|----------------------------|-------------|
| `TINBOX-GOV-1` | Artifact stack roles were implicit | `Open contract gap` | `P0` | `Closed / superseded` | `TI0` | none | docs evidence | closed by local governance pack + artifact stack rule |
| `TINBOX-GOV-2` | Program ledger did not exist | `Open contract gap` | `P0` | `Closed / superseded` | `TI0` | none | docs evidence | closed by `Docs/execution_ledger.md` |
| `TINBOX-GOV-3` | TI1-TI3 lacked tranche specs | `Open contract gap` | `P0` | `Closed / superseded` | `TI0` | none | docs evidence | closed by authoring `TI1`, `TI2`, and `TI3` tranche docs |
| `TINBOX-GOV-4` | Planning-mode policy was not explicit | `Open contract gap` | `P1` | `Closed / superseded` | `TI0` | none | docs evidence | closed in `AGENTS.md` + tranche template |
| `TINBOX-BE-1` | Repo does not expose operator commands for inbox workflows | `Open implementation blocker` | `P0` | `Closed / superseded` | `TI0` | none | static + runtime evidence | closed by `package.json` wiring for `tinbox:check`, `tinbox:deploy:integration`, and `tinbox:smoke` |
| `TINBOX-BE-2` | HA YAML bootstrap for tunet_inbox is missing | `Open implementation blocker` | `P0` | `Closed / superseded` | `TI0` | none | docs + static evidence | closed by local bootstrap wiring and governed remote config patching in the deploy helper |
| `TINBOX-BE-3` | Backend scaffold has not been statically validated end-to-end | `Validation debt` | `P0` | `Closed / superseded` | `TI0` | `TINBOX-BE-1`, `TINBOX-BE-2` | static evidence | closed by `py_compile`, `node --check`, and `npm run tinbox:check` |
| `TINBOX-BE-4` | Deploy/smoke path exists but has no recorded proof | `Validation debt` | `P1` | `Closed / superseded` | `TI1` | `TINBOX-BE-1`, `TINBOX-BE-2` | runtime + HA/live evidence | closed by deploy, config check, HA restart, and passing smoke check on 2026-04-06 |
| `TINBOX-TI1-1` | Service registration and response contract are unproven in HA | `Open implementation blocker` | `P0` | `Closed / superseded` | `TI1` | `TI0` closed | HA/live evidence | closed by live `post`, `list_items`, `respond`, `fail`, `resolve`, and `dismiss` probes |
| `TINBOX-TI1-2` | Final concurrency closure still needs an explicit acceptance decision | `Validation debt` | `P1` | `Closed / superseded` | `TI1` | `TINBOX-TI1-1` | runtime + HA/live evidence | closed by `tinbox:probe:runtime`, which proved the literal `lock_conflict` branch locally after live single-accept proof |
| `TINBOX-TEST-1` | Local Home Assistant integration test harness does not exist | `Open implementation blocker` | `P1` | `Closed / superseded` | `TI1A` | `TI1` closed | docs + static + runtime evidence | closed by `requirements_test.txt`, `pytest.ini`, repo-local venv scripts, and passing `tinbox:test:setup` |
| `TINBOX-TEST-2` | Manager/service/event behavior has no local pytest coverage | `Validation debt` | `P1` | `Closed / superseded` | `TI1A` | `TINBOX-TEST-1` | runtime evidence | closed by the targeted `tests/components/tunet_inbox/` suite and passing `tinbox:test` |
| `TINBOX-PROD-1` | Integration has no config-entry setup path or diagnostics surface | `Open implementation blocker` | `P1` | `Closed / superseded` | `TI1B` | `TI1A` closed | docs + static + runtime + HA/live evidence | closed by config-entry runtime ownership, YAML import path, diagnostics export, and live imported-entry proof |
| `TINBOX-PROD-2` | Integration supportability debt remains visible in metadata and runtime warnings | `Validation debt` | `P2` | `Closed / superseded` | `TI1B` | `TINBOX-PROD-1` | static + runtime evidence | closed by manifest cleanup, translation-backed config UI, extra backend tests, and the UTC warning fix |
| `TINBOX-PROD-3` | Malformed persisted queue items are logged and skipped instead of quarantined | `Open implementation blocker` | `P1` | `In-flight tranche work` | `TI1C` | `TINBOX-PROD-1` | docs + static + runtime + HA/live evidence | add quarantine storage, diagnostics summary, and repair surfacing |
| `TINBOX-PROD-4` | Backend lacks a single governed release-verification path after productization | `Validation debt` | `P2` | `In-flight tranche work` | `TI1C` | `TINBOX-PROD-3` | static + runtime evidence | add and prove one release-verification command for check/test/probe workflow |
| `TINBOX-UI-1` | Tunet inbox card does not exist | `Open implementation blocker` | `P1` | `Deferred by policy` | `TI2` | `TI1C` closed | static + runtime + Tunet validation | implement `TI2` |
| `TINBOX-UI-2` | Dedicated inbox dashboard surfaces do not exist | `Open implementation blocker` | `P2` | `Deferred by policy` | `TI2` | `TINBOX-UI-1` | static + HA/live evidence | implement rehab and standalone dashboard |
| `TINBOX-OAL-1` | OAL actionable flows still use direct mobile paths | `Open implementation blocker` | `P1` | `Deferred by policy` | `TI3` | `TI1A`, `TI2` | HA/live evidence | migrate override reminder + override expiring |
| `TINBOX-OAL-2` | OAL natural resolver ownership is not yet mapped end-to-end | `Open contract gap` | `P2` | `Deferred by policy` | `TI3` | `TINBOX-OAL-1` | docs + HA/live evidence | implement explicit resolve ownership in TI3 |
| `TINBOX-SONOS-1` | Sonos alarm flows still use direct mobile paths | `Open implementation blocker` | `P2` | `Deferred by policy` | `TI4` | `TI3` | HA/live evidence | migrate alarm playing after OAL pilot closes |
| `TINBOX-EXP-1` | TV/timer/confirmable flows are unmigrated | `Deferred by policy` | `P3` | `Deferred by policy` | `TI5` | `TI3`, `TI4` | HA/live evidence | start after pilot migrations |
| `TINBOX-HARDEN-1` | Diagnostics, repairs, and corruption handling are absent | `Deferred by policy` | `P3` | `Deferred by policy` | `TI6` | `TI5` | docs + static + HA/live evidence | implement hardening tranche |
| `TINBOX-HARDEN-2` | `utcnow_iso()` emits a Python 3.12 deprecation warning in the local test suite | `Deferred by policy` | `P3` | `Closed / superseded` | `TI1B` | `TINBOX-PROD-2` | runtime evidence | closed by replacing naive `datetime.utcnow()` usage with timezone-aware UTC |
| `TINBOX-TRACK-1` | Enhancement tracker did not match the new inbox question set | `Open contract gap` | `P1` | `Closed / superseded` | `TI0` | none | docs evidence | closed by `HA-References/tunet_inbox_enhancement_matrix.md` and deprecating the old dashboard tracker |

## Tranche-Owned Open Backlog

### `TI1C`

- close `TINBOX-PROD-3`
- close `TINBOX-PROD-4`

### `TI2`

- close `TINBOX-UI-1`
- close `TINBOX-UI-2`

### `TI3`

- close `TINBOX-OAL-1`
- close `TINBOX-OAL-2`

### `TI4`

- close `TINBOX-SONOS-1`

### `TI5`

- close `TINBOX-EXP-1`

### `TI6`

- close `TINBOX-HARDEN-1`
- close `TINBOX-HARDEN-2`

## Current Highest-Confidence Risks

- `P1`: widening into Tunet before malformed-state handling and repair surfacing are governed
- `P1`: leaving skipped persisted corruption unquarantined would violate the locked backend governance rule
- `P1`: migrating OAL without the dashboard surface, which would violate the recovery requirement

## Control Notes

- The plan is now specific enough at the program level, but execution still must be governed by a fully filled tranche doc each time.
- Plan mode is not required for every narrow edit. It is required at control points:
  - new tranche start
  - public contract change
  - allowed-file widening
  - deploy/restart/rollback ambiguity
  - ownership ambiguity
- `TI1C` is the active tranche
- `TI2` remains intentionally deferred until `TI1C` closes

---

## Detailed Implementation Appendix (2026-04-06)

### Current repo-grounded evidence

- governance stack exists:
  - `custom_components/tunet_inbox/AGENTS.md`
  - `custom_components/tunet_inbox/plan.md`
  - `custom_components/tunet_inbox/handoff.md`
  - `custom_components/tunet_inbox/FIX_LEDGER.md`
  - `custom_components/tunet_inbox/Docs/contracts.md`
  - `custom_components/tunet_inbox/Docs/deploy_and_test.md`
  - `custom_components/tunet_inbox/Docs/TRANCHE_TEMPLATE.md`
  - `custom_components/tunet_inbox/Docs/tranches/TI0_governance_scaffold_core_backend_skeleton.md`
- backend scaffold exists:
  - `__init__.py`
  - `const.py`
  - `config_flow.py`
  - `diagnostics.py`
  - `models.py`
  - `storage.py`
  - `events.py`
  - `mobile.py`
  - `manager.py`
  - `services.py`
  - `manifest.json`
  - `services.yaml`
  - `translations/en.json`
- operator scripts exist:
  - `custom_components/tunet_inbox/scripts/check_tunet_inbox.sh`
  - `custom_components/tunet_inbox/scripts/deploy_tunet_inbox.sh`
  - `custom_components/tunet_inbox/scripts/tunet_inbox_smoke.mjs`

### Current unresolved evidence gaps

- no UI or package migration proof is in scope yet
- malformed persisted queue items are still skipped during restore instead of being quarantined
- no repair issue is raised yet when malformed persisted state is observed
- no single governed local release-verification command exists yet

### Recorded repo and live evidence

- static validation passed on 2026-04-06:
  - `python3 -m py_compile custom_components/tunet_inbox/*.py`
  - `node --check custom_components/tunet_inbox/scripts/tunet_inbox_smoke.mjs`
  - `npm run tinbox:check`
- local pytest validation passed on 2026-04-06:
  - `npm run tinbox:test:setup`
  - `npm run tinbox:test`
  - 10 tests passed under `tests/components/tunet_inbox/`
- deploy helper now:
  - backs up remote `/config/custom_components/tunet_inbox/`
  - backs up remote `/config/configuration.yaml`
  - patches only the governed `tunet_inbox` bootstrap/logger fragments on the live host
- HA/live proof recorded on 2026-04-06:
  - remote deploy completed
  - `ha_check_config()` returned `valid`
  - HA restart succeeded
  - `npm run tinbox:smoke` passed
  - remote imported config-entry proof from `/config/.storage/core.config_entries` showed:
    - `count = 1`
    - `source = import`
    - `title = Tunet Inbox`
  - HA logs showed:
    - `Setting up tunet_inbox`
    - `tunet_inbox initialized`
- governed live service probes recorded:
  - `post` created a no-mobile probe item
  - `list_items` returned the render-normalized item
  - `respond` rejected `item_not_found`
  - `respond` rejected `invalid_action`
  - `respond` rejected `expired`
  - `respond` accepted a valid action
  - second `respond` on the same item rejected with `not_pending`
  - `fail(return_to_pending=true)` returned the item to `pending`
  - second valid `respond` was accepted
  - `resolve(clear_mobile=false)` removed the item from the active queue
  - `dismiss` removed a second probe item from the active queue
  - timeout recovery returned a probe item from `responding` to `pending` with `last_error=handler_timeout`
  - concurrent live probes produced:
    - one accepted `respond`
    - four rejected `respond` calls with `not_pending`
  - deterministic local runtime probe produced:
    - exact `lock_conflict` response while the per-item lock was pre-held

### Program guidance

- do not start card work under `Dashboard/Tunet/**` until the Tunet-side control-point review for `TI2` is complete
- do not start OAL or Sonos migration until the backend service/event path is proven in HA
- do not start OAL or Sonos migration until the backend test harness exists and the targeted backend suite passes
- use the ledger as the normalized issue authority, the plan as the program order authority, and tranche docs as execution authority
