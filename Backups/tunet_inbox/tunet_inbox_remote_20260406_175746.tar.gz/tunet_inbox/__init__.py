"""Tunet Inbox custom integration."""

from __future__ import annotations

from datetime import timedelta
import logging
from typing import Any

import voluptuous as vol

from homeassistant.const import EVENT_HOMEASSISTANT_STARTED
from homeassistant.core import Event, HomeAssistant
import homeassistant.helpers.config_validation as cv
from homeassistant.helpers.event import async_track_time_interval

from .const import (
    CONF_ARCHIVE_RETENTION_DAYS,
    CONF_DEBUG_EVENTS,
    CONF_MAX_PENDING_ITEMS,
    CONF_NOTIFY_DEVICE_HELPER,
    CONF_PRIVACY_MODE_DEFAULT,
    CONF_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_ARCHIVE_RETENTION_DAYS,
    DEFAULT_DEBUG_EVENTS,
    DEFAULT_MAX_PENDING_ITEMS,
    DEFAULT_PRIVACY_MODE_DEFAULT,
    DEFAULT_RESPONSE_TIMEOUT_SECONDS,
    DOMAIN,
)
from .manager import TunetInboxManager
from .mobile import extract_mobile_response
from .services import async_register_services

_LOGGER = logging.getLogger(__name__)

CONFIG_SCHEMA = vol.Schema(
    {
        DOMAIN: vol.Schema(
            {
                vol.Optional(CONF_NOTIFY_DEVICE_HELPER): cv.string,
                vol.Optional(CONF_MAX_PENDING_ITEMS, default=DEFAULT_MAX_PENDING_ITEMS): vol.Coerce(int),
                vol.Optional(
                    CONF_RESPONSE_TIMEOUT_SECONDS, default=DEFAULT_RESPONSE_TIMEOUT_SECONDS
                ): vol.Coerce(int),
                vol.Optional(
                    CONF_ARCHIVE_RETENTION_DAYS, default=DEFAULT_ARCHIVE_RETENTION_DAYS
                ): vol.Coerce(int),
                vol.Optional(
                    CONF_PRIVACY_MODE_DEFAULT, default=DEFAULT_PRIVACY_MODE_DEFAULT
                ): cv.boolean,
                vol.Optional(CONF_DEBUG_EVENTS, default=DEFAULT_DEBUG_EVENTS): cv.boolean,
            }
        )
    },
    extra=vol.ALLOW_EXTRA,
)


async def async_setup(hass: HomeAssistant, config: dict[str, Any]) -> bool:
    """Set up Tunet Inbox from YAML."""
    cfg = config.get(DOMAIN, {})
    manager = TunetInboxManager(hass, cfg)
    await manager.async_initialize()
    hass.data[DOMAIN] = {"manager": manager}

    await async_register_services(hass, manager)

    async def _on_started(_event: Event) -> None:
        await manager.async_reconcile_startup()
        _LOGGER.info("tunet_inbox startup reconcile completed")

    async def _on_mobile_action(event: Event) -> None:
        response = extract_mobile_response(event)
        if not response:
            return
        if not response.get("ok"):
            _LOGGER.warning("tunet_inbox rejected mobile action mapping: %s", response["reason"])
            return
        result = await manager.async_accept_response(
            item_id=response["item_id"],
            action_id=response["action_id"],
            source="phone",
            surface="mobile_app",
            actor=response.get("actor"),
        )
        if not result.get("accepted"):
            _LOGGER.info(
                "tunet_inbox ignored mobile response item_id=%s action_id=%s reason=%s",
                response["item_id"],
                response["action_id"],
                result.get("reason"),
            )

    hass.bus.async_listen_once(EVENT_HOMEASSISTANT_STARTED, _on_started)
    hass.bus.async_listen("mobile_app_notification_action", _on_mobile_action)
    async_track_time_interval(
        hass,
        manager.async_sweep_expired_and_stuck,
        timedelta(seconds=max(15, manager.response_timeout_seconds)),
    )

    _LOGGER.info("tunet_inbox initialized")
    return True

