# Tunet Inbox Handoff

Last updated: 2026-04-06 (America/Denver)  
Working branch: `tunet/inbox-integration`

## Current State

- `tunet_inbox` is being introduced as a new governed custom integration.
- The workstream now has its own scoped execution contract under `custom_components/tunet_inbox/`.
- The program-level status ledger for the project is now:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- The current active tranche is `TI0 — Governance Scaffold + Core Backend Skeleton`.
- `TI0` must now be governed by its tranche spec, not just the top-level plan:
  - `custom_components/tunet_inbox/Docs/tranches/TI0_governance_scaffold_core_backend_skeleton.md`
- No package migrations should be treated as active until `TI1` is complete.

## What Changed This Session

- created the local governance workstream
- fixed the contract source-of-truth location under `custom_components/tunet_inbox/`
- added an explicit planning-control rule:
  - use default execution inside an approved tranche
  - re-enter planning only at tranche or contract control points
- added the normalized program ledger:
  - `custom_components/tunet_inbox/Docs/execution_ledger.md`
- authored tranche specs for:
  - `TI1`
  - `TI2`
  - `TI3`
- replaced the stale dashboard-centric enhancement tracker with:
  - `HA-References/tunet_inbox_enhancement_matrix.md`
- locked the first program-order sequence:
  - governance
  - backend contract/storage
  - service/event pipeline
  - deploy/check/smoke harness
  - UI
  - package migrations

## Current Contract Assumptions

- dashboard ingress must go through `tunet_inbox.respond`
- canonical business event is `tunet_inbox_action`
- queue refresh event is `tunet_inbox_updated`
- raw mobile action format is `TINBOX|<item_id>|<action_id>`
- queue items are governed objects, not arbitrary JSON blobs
- action payloads are identifiers and render metadata only

## Next Highest-Value Work

1. wire `package.json` to the new `tinbox:*` scripts
2. register the YAML config block in `Configuration/configuration.yaml`
3. run the first full static validation pass for `TI0`
4. decide whether to close `TI0` repo-only first or continue straight into live smoke proof

## Deployment Notes

- this worktree does not currently contain a checked-in `.env`
- deploy scripts must therefore support:
  - local `.env` in the current worktree when present
  - fallback to the primary repo root `.env`
- backend deploy must treat Python changes as `HA RESTART`

## Risks / Watchpoints

- package migrations are currently the largest regression risk; do not start them before service semantics are stable
- do not let the Tunet card set the backend contract by accident
- keep receipts and clears explicit; do not overload the queue with informational notifications
- do not silently change action identifiers once package migrations start
